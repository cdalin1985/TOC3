export async function apiRequest(
  method: string, 
  endpoint: string, 
  body?: any, 
  options: RequestInit = {}
): Promise<Response> {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  const requestOptions: RequestInit = {
    method,
    headers,
    ...options,
  };

  if (body) {
    requestOptions.body = JSON.stringify(body);
  }

  const baseUrl = import.meta.env.PROD ? '' : 'http://localhost:5000';
  const url = `${baseUrl}${endpoint}`;

  return fetch(url, requestOptions);
}
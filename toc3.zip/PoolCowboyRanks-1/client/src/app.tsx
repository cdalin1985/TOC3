import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/query-client";
import { Toaster } from "./components/ui/toaster";
import { Route, Switch } from "wouter";
import Home from "./pages/home";
import PlayerDetail from "./pages/player-detail";
import LoginPage from "./pages/login";
import ProfilePage from "./pages/profile";
import LinkPlayerPage from "./pages/link-player";
import { ThemeProvider } from "./components/theme-provider";
import { AuthProvider } from "./hooks/use-auth";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="top-capital-ui-theme">
        <AuthProvider>
          <Toaster />
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/players/:id" component={PlayerDetail} />
            <Route path="/login" component={LoginPage} />
            <Route path="/profile" component={ProfilePage} />
            <Route path="/link-player" component={LinkPlayerPage} />
          </Switch>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
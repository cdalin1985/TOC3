import { createContext, ReactNode, useContext } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Player } from "@shared/schema";

// Define user types
type AccountType = 'player' | 'guest';

type User = {
  id: number;
  username: string;
  accountType: AccountType;
  player: Player | null;
} | null;

type AuthContextType = {
  user: User;
  isLoading: boolean;
  isAuthenticated: boolean;
  isPlayer: boolean;
  playerData: Player | null;
  loginMutation: ReturnType<typeof useLoginMutation>;
  registerMutation: ReturnType<typeof useRegisterMutation>;
  logoutMutation: ReturnType<typeof useLogoutMutation>;
  refetchUser: () => void;
};

// Login data type
type LoginData = {
  username: string;
  password: string;
};

// Registration data type
type RegisterData = {
  username: string;
  password: string;
  accountType: AccountType;
  playerId?: string | number;
};

// Create auth context
const AuthContext = createContext<AuthContextType | null>(null);

// Hook to use auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Simplified user hook for components that just need user data
export function useUser() {
  const { user, isLoading, isAuthenticated, isPlayer, playerData, refetchUser } = useAuth();
  return { user, isLoading, isAuthenticated, isPlayer, playerData, refetchUser };
}

// Login mutation hook
function useLoginMutation() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/auth/login", credentials);
      return res.json();
    },
    onSuccess: (data: User) => {
      queryClient.setQueryData(["/api/auth/user"], data);
      toast({
        title: "Login successful",
        description: `Welcome back, ${data?.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
      });
    },
  });
}

// Register mutation hook
function useRegisterMutation() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: RegisterData) => {
      const res = await apiRequest("POST", "/api/auth/register", data);
      return res.json();
    },
    onSuccess: (data: User) => {
      queryClient.setQueryData(["/api/auth/user"], data);
      toast({
        title: "Registration successful",
        description: `Welcome to Top of the Capital, ${data?.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Please try a different username",
        variant: "destructive",
      });
    },
  });
}

// Logout mutation hook
function useLogoutMutation() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// Auth provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  // Fetch current user
  const {
    data: user,
    error,
    isLoading,
    refetch: refetchUser,
  } = useQuery<User, Error>({
    queryKey: ["/api/auth/user"],
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    // Ensure we always return a valid User type (null is valid per our type)
    select: (data) => data ?? null
  });

  // Initialize mutation hooks
  const loginMutation = useLoginMutation();
  const registerMutation = useRegisterMutation();
  const logoutMutation = useLogoutMutation();

  // Derived states
  const isAuthenticated = !!user;
  const isPlayer = isAuthenticated && user?.accountType === 'player';
  const playerData = isPlayer ? user?.player : null;

  // Create context value
  const value: AuthContextType = {
    user: user ?? null, // Ensure user is always User type, not undefined
    isLoading,
    isAuthenticated,
    isPlayer,
    playerData,
    loginMutation,
    registerMutation,
    logoutMutation,
    refetchUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
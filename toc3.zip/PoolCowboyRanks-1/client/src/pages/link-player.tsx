
import { useState } from "react";
import { useUser } from "@/hooks/use-auth";
import { Navigate, Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Link as LinkIcon, Search } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { Player } from "@shared/schema";
import { useToast } from "@/components/ui/use-toast";
import { queryClient } from "@/lib/query-client";

export default function LinkPlayerPage() {
  const { isAuthenticated, isLoading } = useUser();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: players } = useQuery({
    queryKey: ["players"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/players");
      return res.json() as Promise<Player[]>;
    },
  });

  const { data: myPlayers } = useQuery({
    queryKey: ["myPlayers"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/auth/my-players", null, { credentials: "include" });
      return res.json() as Promise<Player[]>;
    },
    enabled: isAuthenticated,
  });

  const linkMutation = useMutation({
    mutationFn: async (playerId: number) => {
      return apiRequest("POST", `/api/auth/link-player/${playerId}`, null, { credentials: "include" });
    },
    onSuccess: () => {
      toast({
        title: "Player linked",
        description: "The player has been linked to your account.",
      });
      queryClient.invalidateQueries({ queryKey: ["myPlayers"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to link player",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  const filteredPlayers = players?.filter((player) =>
    player.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const myPlayerIds = new Set(myPlayers?.map((p) => p.id) || []);

  return (
    <div className="container py-10">
      <div className="flex items-center mb-6">
        <Link href="/profile">
          <Button variant="ghost" size="sm" className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Profile
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Link Player</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Link Your Player Profile</CardTitle>
          <CardDescription>
            Link your account to your player profile to manage your challenges and rankings.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search players..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-4">
            {filteredPlayers?.map((player) => (
              <div
                key={player.id}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
              >
                <div>
                  <h4 className="font-medium">
                    {player.name} <span className="text-muted-foreground ml-2">#{player.rank}</span>
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {player.wins} wins, {player.losses} losses
                  </p>
                </div>
                {myPlayerIds.has(player.id) ? (
                  <Button variant="outline" disabled>
                    Already Linked
                  </Button>
                ) : (
                  <Button
                    onClick={() => linkMutation.mutate(player.id)}
                    disabled={linkMutation.isPending}
                  >
                    <LinkIcon className="mr-2 h-4 w-4" />
                    Link Player
                  </Button>
                )}
              </div>
            ))}
            {filteredPlayers?.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No players found. Try a different search term.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

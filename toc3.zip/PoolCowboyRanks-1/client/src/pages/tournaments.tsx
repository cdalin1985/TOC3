import { TournamentManagement } from "@/components/tournament-management";
import { Navbar } from "@/components/navbar";

export default function TournamentsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container py-6">
        <TournamentManagement />
      </main>
    </div>
  );
}
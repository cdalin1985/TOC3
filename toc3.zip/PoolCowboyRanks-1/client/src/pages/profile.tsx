
import { useUser } from "@/hooks/use-auth";
import { Navigate } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { Player } from "@shared/schema";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Trophy, Users } from "lucide-react";
import { Link } from "wouter";

export default function ProfilePage() {
  const { user, isAuthenticated, isLoading } = useUser();

  const { data: myPlayers, isLoading: playersLoading } = useQuery({
    queryKey: ["myPlayers"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/auth/my-players", null, { credentials: "include" });
      return res.json() as Promise<Player[]>;
    },
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="container py-10">
      <div className="flex items-center mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">My Profile</h1>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
            <CardDescription>Your account details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-6">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="text-lg">
                  {user?.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="text-xl font-bold">{user?.username}</h3>
                <p className="text-muted-foreground">{user?.email || "No email set"}</p>
              </div>
            </div>
            <Separator className="my-4" />
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Username:</span>
                <span>{user?.username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span>{user?.email || "Not set"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">User ID:</span>
                <span>{user?.id}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>My Players</CardTitle>
              <CardDescription>Players linked to your account</CardDescription>
            </div>
            <Link href="/link-player">
              <Button size="sm">
                <Users className="mr-2 h-4 w-4" />
                Link Player
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {playersLoading ? (
              <div>Loading players...</div>
            ) : myPlayers && myPlayers.length > 0 ? (
              <div className="space-y-4">
                {myPlayers.map((player) => (
                  <div
                    key={player.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant={player.rank <= 10 ? "default" : "outline"} className="h-8 w-8 rounded-full flex items-center justify-center p-2">
                        {player.rank}
                      </Badge>
                      <div>
                        <h4 className="font-medium">{player.name}</h4>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Trophy className="h-3 w-3 mr-1" />
                          <span>
                            {player.wins} W - {player.losses} L
                          </span>
                        </div>
                      </div>
                    </div>
                    <Link href={`/players/${player.id}`}>
                      <Button variant="outline" size="sm">
                        View Stats
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Players Linked</h3>
                <p className="text-muted-foreground mb-4">
                  Link your player profile to manage your stats and challenges.
                </p>
                <Link href="/link-player">
                  <Button>Link Player</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Redirect } from "wouter";
import { useAuth, useUser } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Player } from "@shared/schema";

// UI components
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { LucideLogIn, UserPlus, Trophy } from "lucide-react";

// Login form schema
const loginSchema = z.object({
  username: z.string(),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Register form schema
const registerSchema = z.object({
  accountType: z.enum(["player", "guest"]),
  playerId: z.string().optional(),
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => {
  // If it's a guest account, no need to validate playerId
  if (data.accountType === "guest") return true;

  // For player accounts, playerId is required
  return !!data.playerId && data.playerId !== "";
}, {
  message: "Please select a player from the list",
  path: ["playerId"],
});

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();
  
  // Fetch players list
  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });

  // Redirect if already logged in
  if (user) {
    return <Redirect to="/" />;
  }

  // Login form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      accountType: "player",
      playerId: "",
      username: "",
      password: "",
    },
  });

  // Watch account type for conditional fields
  const accountType = registerForm.watch("accountType");
  
  // If account type is player, update username to match player name
  const selectedPlayerId = registerForm.watch("playerId");
  
  useEffect(() => {
    if (accountType === "player" && selectedPlayerId) {
      const selectedPlayer = players.find(p => p.id.toString() === selectedPlayerId);
      if (selectedPlayer) {
        // Just set the name without the rank for username
        registerForm.setValue("username", selectedPlayer.name);
      }
    } else if (accountType === "guest") {
      registerForm.setValue("username", "");
    }
  }, [accountType, selectedPlayerId, players, registerForm]);

  // Handle login form submission
  const onLoginSubmit = (values: z.infer<typeof loginSchema>) => {
    loginMutation.mutate({
      username: values.username,
      password: values.password
    });
  };

  // Handle register form submission
  const onRegisterSubmit = (values: z.infer<typeof registerSchema>) => {
    console.log("Submitting registration:", {
      username: values.username,
      password: values.password,
      accountType: values.accountType,
      playerId: values.accountType === "player" ? values.playerId : undefined
    });
    
    registerMutation.mutate({
      username: values.username,
      password: values.password,
      accountType: values.accountType,
      playerId: values.accountType === "player" ? values.playerId : undefined
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-b from-background to-primary/5">
      {/* Left column - Forms */}
      <div className="flex-1 flex items-center justify-center p-6">
        <Card className="w-full max-w-md border-primary/20 shadow-lg bg-blue-950/70 text-white">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-300 to-blue-100 bg-clip-text text-transparent">Welcome</CardTitle>
            <CardDescription className="text-blue-200">
              Sign in or create an account to manage your pool player profile
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4 bg-blue-900/60">
                <TabsTrigger value="login" className="flex items-center gap-2 data-[state=active]:bg-blue-700">
                  <LucideLogIn className="h-4 w-4" /> Login
                </TabsTrigger>
                <TabsTrigger value="register" className="flex items-center gap-2 data-[state=active]:bg-blue-700">
                  <UserPlus className="h-4 w-4" /> Sign Up
                </TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-blue-100">Username</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter your username" 
                              className="bg-blue-900/30 border-blue-500/30 text-blue-100"
                              {...field} 
                            />
                          </FormControl>
                          <div className="mt-1 text-sm text-blue-300">
                            <span className="font-medium">Available players: </span>
                            {players.slice(0, 5).map((player, i) => (
                              <span 
                                key={player.id} 
                                className="cursor-pointer hover:text-blue-200 mr-2"
                                onClick={() => loginForm.setValue("username", player.name)}
                              >
                                {player.name}{i < Math.min(players.length, 5) - 1 ? "," : ""}
                              </span>
                            ))}
                            {players.length > 5 && <span>...</span>}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-blue-100">Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="Enter your password" 
                              className="bg-blue-900/30 border-blue-500/30 text-blue-100"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white" 
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? "Signing in..." : "Sign In"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              <TabsContent value="register">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="accountType"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel className="text-blue-100">Account Type</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="player" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer text-blue-100">
                                  Player Account
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="guest" />
                                </FormControl>
                                <FormLabel className="font-normal cursor-pointer text-blue-100">
                                  Guest Account
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {accountType === "player" && (
                      <FormField
                        control={registerForm.control}
                        name="playerId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-blue-100">Select Your Name</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-blue-900/30 border-blue-500/30 text-blue-100">
                                  <SelectValue placeholder="Select your name from the list" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-blue-900 border-blue-500/30 text-blue-100">
                                {players.map((player) => (
                                  <SelectItem key={player.id} value={player.id.toString()}>
                                    {player.name} (#{player.rank})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription className="text-blue-300">
                              This will link your account to your player profile
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    {accountType === "guest" && (
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-blue-100">Username</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Choose a username" 
                                className="bg-blue-900/30 border-blue-500/30 text-blue-100"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-blue-100">Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="Choose a password" 
                              className="bg-blue-900/30 border-blue-500/30 text-blue-100"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white" 
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Right column - Hero image/text */}
      <div className="flex-1 bg-gradient-to-tr from-blue-950 to-blue-900 hidden md:flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-grid-white/5" />
        </div>
        
        <div className="relative z-10 max-w-md text-center space-y-6">
          <div className="rounded-full bg-blue-500/20 w-20 h-20 mx-auto flex items-center justify-center">
            <Trophy className="h-10 w-10 text-blue-300" />
          </div>
          
          <h1 className="text-4xl font-bold text-white">Top of the Capital</h1>
          
          <p className="text-blue-200 text-lg">
            Welcome to Helena's premier pool player ranking system. Track your games, challenge opponents, and rise through the ranks.
          </p>
          
          <div className="pt-6">
            <div className="text-blue-100 font-semibold mb-2">Features</div>
            <ul className="text-blue-300 space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                <span>Challenge higher ranked players</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                <span>Track your match history and stats</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                <span>Compete in 8-ball, 9-ball, and 10-ball</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                <span>Join tournaments with automated brackets</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
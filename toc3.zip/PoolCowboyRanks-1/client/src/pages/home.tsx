import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChallengeDialog } from "@/components/challenge-dialog";
import { StatisticsDashboard } from "@/components/statistics-dashboard";
import { MatchHistory } from "@/components/match-history";
import { NotificationsPanel } from "@/components/notifications-panel";
import { PlayerRankings } from "@/components/player-rankings";
import { Navbar } from "@/components/navbar";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/api";
import { Player, Challenge } from "@shared/schema";
import { useState, useEffect } from "react";
import { Trophy, Star, Shield, History, Bell, BarChart, Award } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/hooks/use-auth";
import { Link } from "wouter";

export default function Home() {
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const { toast } = useToast();
  const { user, isAuthenticated } = useUser();

  const { data: players = [], isLoading: playersLoading } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });

  const { data: challenges = [] } = useQuery<Challenge[]>({
    queryKey: ["/api/challenges"],
  });
  
  const { data: myPlayers = [] } = useQuery({
    queryKey: ["myPlayers"],
    queryFn: async () => {
      if (!isAuthenticated) return [];
      const res = await apiRequest("GET", "/api/auth/my-players", null, { credentials: "include" });
      return res.json();
    },
    enabled: isAuthenticated,
  });

  const updateChallenge = useMutation({
    mutationFn: async ({ 
      challengeId, 
      status, 
      winnerId 
    }: { 
      challengeId: number;
      status: string;
      winnerId?: number;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/challenges/${challengeId}/status`,
        { status, winnerId }
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/challenges"] });
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      toast({
        title: "Challenge updated",
        description: "The challenge has been updated successfully.",
      });
    },
  });

  const pendingChallenges = challenges.filter(c => c.status === "pending");

  const [selectedPlayerId, setSelectedPlayerId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("rankings");

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 p-4">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-6xl font-bold tracking-tight neon-text fancy-title">
              Top of the Capital
            </h1>
            <p className="text-xl text-blue-300 font-serif italic">
              Challenge opponents and claim your spot at the top
            </p>
          </div>
        
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full bg-blue-950/50 border border-blue-500/20">
              <TabsTrigger value="rankings" className="flex gap-2 futuristic-bold data-[state=active]:bg-blue-800/30 data-[state=active]:text-blue-100 data-[state=active]:shadow-[0_0_10px_rgba(0,150,255,0.3)]">
                <Trophy className="h-4 w-4" /> Rankings
              </TabsTrigger>
              <TabsTrigger value="statistics" className="flex gap-2 futuristic-bold data-[state=active]:bg-blue-800/30 data-[state=active]:text-blue-100 data-[state=active]:shadow-[0_0_10px_rgba(0,150,255,0.3)]">
                <BarChart className="h-4 w-4" /> Statistics
              </TabsTrigger>
              <TabsTrigger value="history" className="flex gap-2 futuristic-bold data-[state=active]:bg-blue-800/30 data-[state=active]:text-blue-100 data-[state=active]:shadow-[0_0_10px_rgba(0,150,255,0.3)]">
                <History className="h-4 w-4" /> History
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex gap-2 futuristic-bold data-[state=active]:bg-blue-800/30 data-[state=active]:text-blue-100 data-[state=active]:shadow-[0_0_10px_rgba(0,150,255,0.3)]">
                <Bell className="h-4 w-4" /> Notifications
              </TabsTrigger>
            </TabsList>
            
            <div className="flex justify-end">
              <Link href="/tournaments">
                <Button variant="outline" className="flex items-center gap-2 neon-border futuristic-bold">
                  <Award className="h-4 w-4 text-blue-300" />
                  Go to Tournaments
                </Button>
              </Link>
            </div>
            
            <TabsContent value="rankings" className="space-y-4">
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="md:col-span-2 player-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-2xl neon-text futuristic-bold">
                      <Star className="h-8 w-8 text-blue-300" />
                      The List
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {/* Include the new animated player rankings component */}
                    <PlayerRankings />
                  </CardContent>
                </Card>

                <Card className="player-card">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 neon-text futuristic-bold">
                      <Shield className="h-6 w-6 text-blue-300" />
                      Active Challenges
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {pendingChallenges.length === 0 ? (
                      <p className="text-center text-blue-200/60 py-4 tech-font">
                        No pending challenges
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {pendingChallenges.map((challenge) => {
                          const challenger = players.find(p => p.id === challenge.challengerId);
                          const defender = players.find(p => p.id === challenge.defenderId);

                          return (
                            <div key={challenge.id} className="p-4 player-card rounded-lg space-y-2">
                              <p className="font-bold text-lg player-name">
                                {challenger?.name} <span className="text-blue-400">vs</span> {defender?.name}
                              </p>
                              <p className="text-sm text-blue-200 tech-font">
                                {challenge.gameType} - First to {challenge.gamesToWin}
                              </p>
                              <div className="flex gap-2 pt-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-primary neon-border hover:bg-primary/20 futuristic-bold"
                                  onClick={() => updateChallenge.mutate({
                                    challengeId: challenge.id,
                                    status: "accepted"
                                  })}
                                >
                                  Accept
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-destructive text-destructive hover:bg-destructive/20 futuristic-bold"
                                  onClick={() => updateChallenge.mutate({
                                    challengeId: challenge.id,
                                    status: "rejected"
                                  })}
                                >
                                  Reject
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="statistics" className="space-y-4">
              {/* Player selection for statistics */}
              <Card className="player-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 neon-text futuristic-bold">
                    <BarChart className="h-6 w-6 text-blue-300" />
                    Player Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1">
                      <p className="mb-2 text-sm text-blue-200 tech-font">Select a player to view their statistics:</p>
                      <select 
                        className="w-full p-2 border border-blue-500/30 rounded-md bg-blue-900/20 text-blue-100" 
                        value={selectedPlayerId || ""}
                        onChange={(e) => setSelectedPlayerId(e.target.value ? parseInt(e.target.value) : null)}
                      >
                        <option value="">Select a player</option>
                        {players.map((player) => (
                          <option key={player.id} value={player.id} className="bg-blue-900">
                            {player.name} (Rank: {player.rank})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {selectedPlayerId && (
                <StatisticsDashboard playerId={selectedPlayerId} />
              )}
            </TabsContent>
            
            <TabsContent value="history">
              <MatchHistory />
            </TabsContent>
            
            <TabsContent value="notifications">
              {selectedPlayerId ? (
                <NotificationsPanel playerId={selectedPlayerId} />
              ) : (
                <Card className="player-card">
                  <CardContent className="py-10 text-center">
                    <Bell className="h-12 w-12 mx-auto mb-4 text-blue-300/60" />
                    <p className="text-blue-200/60 tech-font">
                      Please select a player in the Statistics tab to view notifications
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <ChallengeDialog
        player={selectedPlayer}
        onClose={() => setSelectedPlayer(null)}
        players={players}
      />
    </div>
  );
}
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark" | "system">("system");

  useEffect(() => {
    const root = window.document.documentElement;
    const isDark = 
      theme === "dark" ||
      (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    
    root.classList.toggle("dark", isDark);
  }, [theme]);

  function toggleTheme(value: "light" | "dark" | "system") {
    setTheme(value);
    localStorage.setItem("theme", value);
  }

  // Initialize theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "light" | "dark" | "system" | null;
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="border-blue-400/30 bg-blue-900/30 hover:bg-blue-800/50 text-blue-200">
          <Sun className="h-5 w-5 rotate-0 scale-100 transition-all text-blue-300 dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all text-blue-300 dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-blue-950 border border-blue-500/30">
        <DropdownMenuItem 
          onClick={() => toggleTheme("light")}
          className="text-blue-200 hover:bg-blue-900 cursor-pointer flex items-center"
        >
          <Sun className="mr-2 h-4 w-4 text-blue-400" />
          Light
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => toggleTheme("dark")}
          className="text-blue-200 hover:bg-blue-900 cursor-pointer flex items-center"
        >
          <Moon className="mr-2 h-4 w-4 text-blue-400" />
          Dark
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => toggleTheme("system")}
          className="text-blue-200 hover:bg-blue-900 cursor-pointer flex items-center"
        >
          <span className="mr-2 h-4 w-4 text-blue-400 flex items-center justify-center">
            <Sun className="h-3 w-3" />
          </span>
          System
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
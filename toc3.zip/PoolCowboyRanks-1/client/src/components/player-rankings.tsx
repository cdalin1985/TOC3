import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Award, Medal, ChevronUp, ChevronDown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ChallengeDialog } from "@/components/challenge-dialog";

// Define player interface
interface Player {
  id: number;
  name: string;
  rank: number;
  wins: number;
  losses: number;
  fargoRating: number | null;
  totalGamesPlayed: number;
  activeChallenges: number;
  highestRankAchieved: number | null;
  phoneNumber: string | null;
}

export function PlayerRankings() {
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [showChallengeDialog, setShowChallengeDialog] = useState(false);
  const [previousPlayers, setPreviousPlayers] = useState<Player[]>([]);

  // Fetch players data
  const { data: players = [], isLoading } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });

  // Fetch current user data
  const { data: currentUser } = useQuery<{
    id: number;
    username: string;
    accountType: string;
    player: Player | null;
  }>({
    queryKey: ["/api/auth/user"],
  });

  // Store previous players data for animation comparison
  useEffect(() => {
    if (players.length > 0) {
      setPreviousPlayers(prevPlayers => {
        // Only update if we have different data (to prevent unnecessary re-renders)
        if (prevPlayers.length === 0) return [...players];
        
        // Check if rankings have changed
        const hasRankingChanged = players.some((player, index) => 
          index < prevPlayers.length && player.id !== prevPlayers[index].id
        );
        
        return hasRankingChanged ? [...players] : prevPlayers;
      });
    }
  }, [players]);

  const getRankChangeInfo = (player: Player) => {
    if (previousPlayers.length === 0) return { changed: false, direction: 0 };
    
    const currentIndex = players.findIndex(p => p.id === player.id);
    const previousIndex = previousPlayers.findIndex(p => p.id === player.id);
    
    if (previousIndex === -1 || currentIndex === previousIndex) {
      return { changed: false, direction: 0 };
    }
    
    return { 
      changed: true, 
      direction: previousIndex > currentIndex ? 1 : -1 // 1 for up, -1 for down
    };
  };

  const handleChallengeClick = (player: Player) => {
    setSelectedPlayer(player);
    setShowChallengeDialog(true);
  };

  const handleCloseDialog = () => {
    setShowChallengeDialog(false);
    setSelectedPlayer(null);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(10)].map((_, i) => (
          <Card key={i} className="overflow-hidden bg-blue-950/40 border-blue-800/50">
            <CardContent className="p-0">
              <div className="flex items-center p-4">
                <div className="flex-shrink-0 mr-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                </div>
                <div className="flex-grow">
                  <Skeleton className="h-4 w-48 mb-2" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <div className="flex-shrink-0">
                  <Skeleton className="h-9 w-24" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-blue-100">Player Rankings</h2>
      </div>

      <div className="grid gap-3">
        <AnimatePresence initial={false}>
          {players.map((player) => {
            const { changed, direction } = getRankChangeInfo(player);
            const isCurrentUserPlayer = currentUser?.player?.id === player.id;
            
            return (
              <motion.div
                key={player.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ 
                  opacity: 1, 
                  y: changed && direction > 0 ? [0, -10, 0] : 0,
                  scale: changed ? [1, 1.02, 1] : 1, // Pulse effect on rank change
                  transition: { 
                    type: "spring", 
                    stiffness: changed && direction > 0 ? 400 : 300, 
                    damping: changed && direction > 0 ? 15 : 30,
                    delay: player.rank * 0.05, // Stagger effect
                    y: {
                      duration: 0.6,
                      times: [0, 0.6, 1]
                    },
                    scale: { 
                      duration: 0.5,
                      repeat: changed ? 1 : 0,
                      repeatType: "reverse"
                    }
                  }
                }}
                exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2 } }}
                layout
                layoutId={`player-${player.id}`}
                className={`${changed ? 'z-10' : ''}`}
                transition={{
                  type: "spring",
                  stiffness: 400,
                  damping: 25,
                  mass: 1
                }}
              >
                <Card className={`overflow-hidden ${
                  isCurrentUserPlayer 
                    ? 'bg-blue-900/30 border-blue-500' 
                    : changed 
                      ? direction > 0
                        ? 'bg-blue-950/40 border-green-700/40 shadow-lg shadow-green-700/10' 
                        : 'bg-blue-950/40 border-red-700/40 shadow-lg shadow-red-700/10'
                      : 'bg-blue-950/40 border-blue-800/50'
                }`}>
                  <CardContent className="p-0">
                    <div className="flex items-center p-4">
                      {/* Rank indicator with medal for top 3 */}
                      <div className="flex items-center justify-center h-12 w-12 rounded-full mr-4 relative">
                        <div className={`flex items-center justify-center h-12 w-12 rounded-full 
                          ${player.rank <= 3 ? 'bg-gradient-to-br' : 'bg-blue-900/20'} 
                          ${player.rank === 1 ? 'from-amber-400 to-amber-600' : 
                            player.rank === 2 ? 'from-slate-300 to-slate-400' : 
                            player.rank === 3 ? 'from-amber-700 to-amber-800' : 'text-blue-300'}`}
                        >
                          {player.rank === 1 ? (
                            <Trophy className="h-6 w-6 text-blue-950" />
                          ) : player.rank === 2 ? (
                            <Award className="h-6 w-6 text-blue-950" />
                          ) : player.rank === 3 ? (
                            <Medal className="h-6 w-6 text-blue-950" />
                          ) : (
                            <span className="text-lg font-bold">{player.rank}</span>
                          )}
                        </div>
                        
                        {/* Rank change indicator */}
                        {changed && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0 }}
                            animate={{ 
                              opacity: 1, 
                              scale: [0, 1.2, 1],
                              transition: {
                                scale: {
                                  duration: 0.4,
                                  times: [0, 0.6, 1]
                                }
                              }
                            }}
                            className="absolute -top-2 -right-2 bg-blue-800 rounded-full p-0.5 shadow-lg shadow-blue-500/20"
                          >
                            {direction > 0 ? (
                              <motion.div 
                                animate={{ y: [0, -2, 0, -2, 0] }}
                                transition={{ duration: 1, repeat: 2, repeatType: "loop" }}
                                className="bg-green-500 rounded-full p-0.5"
                              >
                                <ChevronUp className="h-3 w-3" />
                              </motion.div>
                            ) : (
                              <motion.div
                                animate={{ y: [0, 2, 0, 2, 0] }}
                                transition={{ duration: 1, repeat: 2, repeatType: "loop" }}
                                className="bg-red-500 rounded-full p-0.5"
                              >
                                <ChevronDown className="h-3 w-3" />
                              </motion.div>
                            )}
                          </motion.div>
                        )}
                      </div>
                      
                      {/* Player info */}
                      <div className="flex-grow">
                        <div className="flex items-center">
                          <Avatar className="h-10 w-10 mr-3 border-2 border-blue-700">
                            <AvatarFallback className="bg-blue-800 text-blue-200">
                              {player.name.split(" ").map(n => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <h3 className="font-bold text-lg text-blue-100">
                              {player.name}
                              {changed && (
                                <motion.span
                                  initial={{ opacity: 0, x: direction > 0 ? -20 : 20 }}
                                  animate={{ 
                                    opacity: 1, 
                                    x: 0,
                                    scale: direction > 0 ? [1, 1.1, 1] : 1,
                                    y: direction > 0 ? [0, -2, 0] : [0, 2, 0],
                                  }}
                                  transition={{
                                    duration: 0.5,
                                    scale: { repeat: 2, repeatType: "reverse", duration: 0.3 },
                                    y: { repeat: 2, repeatType: "reverse", duration: 0.3 }
                                  }}
                                  className={`ml-2 text-xs font-normal px-2 py-0.5 rounded ${
                                    direction > 0 
                                      ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
                                      : 'bg-red-500/20 text-red-300 border border-red-500/30'
                                  }`}
                                >
                                  {direction > 0 
                                    ? <span className="flex items-center">Moved up<ChevronUp className="h-3 w-3 ml-1" /></span> 
                                    : <span className="flex items-center">Moved down<ChevronDown className="h-3 w-3 ml-1" /></span>}
                                </motion.span>
                              )}
                            </h3>
                            <div className="flex gap-2 text-sm text-blue-300">
                              <span>{player.wins} wins</span>
                              <span>•</span>
                              <span>{player.losses} losses</span>
                              {player.fargoRating && (
                                <>
                                  <span>•</span>
                                  <span>Fargo: {player.fargoRating}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Challenge button */}
                      <div className="flex-shrink-0">
                        <Button
                          onClick={() => handleChallengeClick(player)}
                          variant="outline"
                          className="bg-blue-800/30 border-blue-700/50 hover:bg-blue-700/30 hover:text-blue-100"
                        >
                          Challenge
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Challenge dialog */}
      {showChallengeDialog && (
        <ChallengeDialog
          player={selectedPlayer}
          onClose={handleCloseDialog}
          players={players}
        />
      )}
    </div>
  );
}
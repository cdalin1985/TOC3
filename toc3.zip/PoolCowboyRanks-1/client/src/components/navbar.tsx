import { Award, Home, Trophy } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { Link, useLocation } from "wouter";
import { UserMenu } from "@/components/auth/user-menu";
import { useUser } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();
  const { user, isAuthenticated } = useUser();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-blue-500/30 bg-blue-950/90 backdrop-blur supports-[backdrop-filter]:bg-blue-950/60">
      <div className="container flex h-16 items-center">
        <Link href="/" className="flex items-center gap-2 mr-6">
          <Trophy className="h-7 w-7 text-blue-300" />
          <span className="hidden sm:inline font-bold fancy-title text-xl neon-text">Top of the Capital</span>
        </Link>
        
        <nav className="hidden md:flex items-center space-x-6 lg:space-x-8 mx-6">
          <Link href="/" className={cn(
            "text-base tech-font font-medium transition-colors hover:text-blue-300 flex items-center gap-2",
            location === "/" ? "text-blue-300 neon-text" : "text-blue-200/80"
          )}>
            <Home className="h-5 w-5" />
            Rankings
          </Link>
          
          <Link href="/tournaments" className={cn(
            "text-base tech-font font-medium transition-colors hover:text-blue-300 flex items-center gap-2",
            location === "/tournaments" ? "text-blue-300 neon-text" : "text-blue-200/80"
          )}>
            <Award className="h-5 w-5" />
            Tournaments
          </Link>
        </nav>
        
        <div className="flex flex-1 items-center justify-end space-x-3">
          <UserMenu />
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
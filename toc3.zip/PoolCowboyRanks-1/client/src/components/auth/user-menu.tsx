
import { User, LogOut, UserPlus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "wouter";

export function UserMenu() {
  const { user, isAuthenticated, logoutMutation } = useAuth(); // Use full useAuth instead of useUser

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (!isAuthenticated) {
    return (
      <Link href="/auth">
        <Button variant="outline" className="gap-2 border-blue-400/30 bg-blue-900/30 hover:bg-blue-800/50 text-blue-200 font-medium text-base">
          <User className="h-5 w-5" />
          Login
        </Button>
      </Link>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2 border-blue-400/30 bg-blue-900/30 hover:bg-blue-800/50 text-blue-200">
          <Avatar className="h-7 w-7 border border-blue-300/50">
            <AvatarFallback className="bg-blue-700 text-blue-100 font-medium">
              {user?.username.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="hidden md:inline tech-font text-base">{user?.username}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-blue-950 border border-blue-500/30">
        <DropdownMenuLabel className="text-blue-300 font-semibold tech-font">My Account</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-blue-700/30" />
        <Link href="/profile">
          <DropdownMenuItem className="text-blue-200 hover:bg-blue-900 cursor-pointer">
            <User className="mr-2 h-5 w-5 text-blue-400" />
            <span>Profile</span>
          </DropdownMenuItem>
        </Link>
        <Link href="/link-player">
          <DropdownMenuItem className="text-blue-200 hover:bg-blue-900 cursor-pointer">
            <UserPlus className="mr-2 h-5 w-5 text-blue-400" />
            <span>Link Player</span>
          </DropdownMenuItem>
        </Link>
        <DropdownMenuSeparator className="bg-blue-700/30" />
        <DropdownMenuItem onClick={handleLogout} className="text-blue-200 hover:bg-blue-900 cursor-pointer">
          <LogOut className="mr-2 h-5 w-5 text-blue-400" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

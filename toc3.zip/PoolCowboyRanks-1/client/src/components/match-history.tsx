import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useState } from "react";
import { format } from "date-fns";
import { CalendarIcon, Download, FilterX, Search, Clock, Plus, Trophy, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { Player, Challenge } from "@shared/schema";
import { DateRange } from "react-day-picker";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";

interface Match {
  id: number;
  challengeId: number;
  player1Id: number;
  player2Id: number;
  player1Score: number;
  player2Score: number;
  winnerId: number;
  gameType: string;
  date: string;
}

// Used for direct match recording dialog
interface MatchFormData {
  player1Id: number;
  player2Id: number;
  player1Score: number;
  player2Score: number;
  gameType: string;
  challengeId?: number;
}

// Used for challenge completion dialog
interface ChallengeCompletionFormData {
  challengeId: number;
  player1Score: number;
  player2Score: number;
  winnerId: number;
}

export function MatchHistory() {
  const [page, setPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  // Default to an empty date range
  const [dateRange, setDateRange] = useState<DateRange>({
    from: undefined,
    to: undefined
  });
  const [gameTypeFilter, setGameTypeFilter] = useState<string>("");

  const { data: matches = [] } = useQuery<Match[]>({
    queryKey: ["/api/matches"],
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });
  
  const { data: challenges = [] } = useQuery<Challenge[]>({
    queryKey: ["/api/challenges"],
  });
  
  const [showRecordMatchDialog, setShowRecordMatchDialog] = useState(false);
  const [showMatchDetailsDialog, setShowMatchDetailsDialog] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [selectedGameType, setSelectedGameType] = useState<string>("8ball");
  const [selectedPlayer1, setSelectedPlayer1] = useState<number | null>(null);
  const [selectedPlayer2, setSelectedPlayer2] = useState<number | null>(null);
  const [player1Score, setPlayer1Score] = useState<number>(0);
  const [player2Score, setPlayer2Score] = useState<number>(0);
  const { toast } = useToast();
  
  // Mutation for recording a direct match
  const recordMatchMutation = useMutation({
    mutationFn: async (data: MatchFormData) => {
      // First create a challenge
      const challengeRes = await apiRequest("POST", "/api/challenges", {
        challengerId: data.player1Id,
        defenderId: data.player2Id,
        gameType: data.gameType,
        gamesToWin: Math.max(data.player1Score, data.player2Score)
      });
      
      const challenge = await challengeRes.json();
      
      // Then complete it with a result
      const winnerId = data.player1Score > data.player2Score 
        ? data.player1Id 
        : data.player2Id;
        
      await apiRequest("POST", `/api/challenges/${challenge.id}/status`, {
        status: "completed",
        winnerId
      });
      
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
      queryClient.invalidateQueries({ queryKey: ["/api/challenges"] });
      queryClient.invalidateQueries({ queryKey: ["/api/players"] });
      
      toast({
        title: "Match recorded",
        description: "The match has been recorded successfully.",
      });
      
      // Reset form
      setSelectedPlayer1(null);
      setSelectedPlayer2(null);
      setPlayer1Score(0);
      setPlayer2Score(0);
      setShowRecordMatchDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Error recording match",
        description: error.message || "There was a problem recording the match.",
        variant: "destructive"
      });
    }
  });

  // Apply filters
  const filteredMatches = matches.filter(match => {
    const player1 = players.find(p => p.id === match.player1Id);
    const player2 = players.find(p => p.id === match.player2Id);
    const matchDate = new Date(match.date);
    
    // Search filter
    const searchMatch = 
      !searchTerm || 
      player1?.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      player2?.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Date filter
    const dateMatch = 
      (!dateRange?.from || matchDate >= dateRange.from) && 
      (!dateRange?.to || matchDate <= dateRange.to);
    
    // Game type filter
    const gameTypeMatch = !gameTypeFilter || match.gameType === gameTypeFilter;
    
    return searchMatch && dateMatch && gameTypeMatch;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const itemsPerPage = 10;
  const maxPage = Math.ceil(filteredMatches.length / itemsPerPage);

  // Paginate results
  const paginatedMatches = filteredMatches.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  const clearFilters = () => {
    setSearchTerm("");
    setDateRange({ from: undefined, to: undefined });
    setGameTypeFilter("");
    setPage(1);
  };

  const getPlayerName = (id: number) => {
    const player = players.find(p => p.id === id);
    return player ? player.name : `Player #${id}`;
  };

  const exportToCSV = () => {
    // Generate CSV data
    const headers = ["Date", "Player 1", "Player 2", "Game Type", "Score", "Winner"];
    const csvData = filteredMatches.map(match => [
      format(new Date(match.date), "yyyy-MM-dd"),
      getPlayerName(match.player1Id),
      getPlayerName(match.player2Id),
      match.gameType,
      `${match.player1Score}-${match.player2Score}`,
      getPlayerName(match.winnerId)
    ]);
    
    // Add headers
    csvData.unshift(headers);
    
    // Convert to CSV string
    const csvString = csvData.map(row => row.join(",")).join("\n");
    
    // Create download link
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `match_history_${format(new Date(), "yyyy-MM-dd")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col gap-4">
      <Card className="w-full player-card">
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="text-2xl neon-text flex items-center gap-2 futuristic-bold">
              <Clock className="h-6 w-6 text-blue-300" />
              Match History
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowRecordMatchDialog(true)} 
                className="neon-border futuristic-bold"
              >
                <Plus className="h-4 w-4 mr-1 text-blue-300" />
                Record Match
              </Button>
              <Button variant="outline" size="sm" onClick={exportToCSV} className="neon-border futuristic-bold">
                <Download className="h-4 w-4 mr-1 text-blue-300" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-blue-300" />
                <Input
                  placeholder="Search players..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setPage(1);
                  }}
                  className="pl-8 border-blue-500/30 bg-blue-900/20 text-blue-100 placeholder:text-blue-300/50"
                />
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "justify-start text-left font-normal w-full sm:w-auto tech-font border-blue-500/30 bg-blue-900/20",
                      !dateRange.from && !dateRange.to && "text-blue-300/50"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4 text-blue-300" />
                    {dateRange.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd, y")} -{" "}
                          {format(dateRange.to, "LLL dd, y")}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y")
                      )
                    ) : (
                      "Date range"
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-blue-950 border border-blue-500/30" align="end">
                  <Calendar
                    initialFocus
                    mode="range"
                    selected={dateRange}
                    onSelect={(value) => {
                      if (value) {
                        setDateRange({ 
                          from: value.from, 
                          to: value.to ? value.to : value.from 
                        });
                      } else {
                        setDateRange({ from: undefined, to: undefined });
                      }
                      setPage(1);
                    }}
                    numberOfMonths={1}
                    className="bg-blue-950"
                  />
                </PopoverContent>
              </Popover>
              
              <Select 
                value={gameTypeFilter} 
                onValueChange={(value) => {
                  setGameTypeFilter(value);
                  setPage(1);
                }}
              >
                <SelectTrigger className="w-full sm:w-[150px] border-blue-500/30 bg-blue-900/20 tech-font">
                  <SelectValue placeholder="Game Type" className="text-blue-300/50" />
                </SelectTrigger>
                <SelectContent className="bg-blue-950 border border-blue-500/30">
                  <SelectItem value="" className="tech-font">All Games</SelectItem>
                  <SelectItem value="8ball" className="tech-font">8-Ball</SelectItem>
                  <SelectItem value="9ball" className="tech-font">9-Ball</SelectItem>
                  <SelectItem value="10ball" className="tech-font">10-Ball</SelectItem>
                </SelectContent>
              </Select>
              
              {(searchTerm || dateRange.from || dateRange.to || gameTypeFilter) && (
                <Button variant="ghost" onClick={clearFilters} size="icon" className="text-blue-300 hover:text-blue-100 hover:bg-blue-800/20">
                  <FilterX className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          
          {filteredMatches.length === 0 ? (
            <div className="text-center py-12 text-blue-200/60 tech-font">
              No matches found.
            </div>
          ) : (
            <>
              <div className="rounded-md border border-blue-500/30 overflow-hidden">
                <Table>
                  <TableHeader className="bg-blue-900/20">
                    <TableRow className="hover:bg-blue-800/20 border-blue-500/30">
                      <TableHead className="text-blue-200 futuristic-bold">Date</TableHead>
                      <TableHead className="text-blue-200 futuristic-bold">Players</TableHead>
                      <TableHead className="text-blue-200 futuristic-bold">Game</TableHead>
                      <TableHead className="text-blue-200 futuristic-bold">Score</TableHead>
                      <TableHead className="text-blue-200 futuristic-bold">Winner</TableHead>
                      <TableHead className="text-blue-200 futuristic-bold text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedMatches.map((match) => {
                      const player1 = players.find(p => p.id === match.player1Id);
                      const player2 = players.find(p => p.id === match.player2Id);
                      const winner = players.find(p => p.id === match.winnerId);
                      
                      return (
                        <TableRow key={match.id} className="hover:bg-blue-800/20 border-blue-500/30">
                          <TableCell className="whitespace-nowrap text-blue-100 futuristic-bold">
                            {format(new Date(match.date), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            <div className="font-medium player-name text-blue-100">{player1?.name}</div>
                            <div className="text-sm text-blue-300/70 futuristic-bold">vs. {player2?.name}</div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-blue-900/30 text-blue-200 border-blue-500/40 futuristic-bold">
                              {match.gameType}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-blue-100 futuristic-bold">
                            {match.player1Score} - {match.player2Score}
                          </TableCell>
                          <TableCell>
                            <Badge className={cn(
                              "futuristic-bold",
                              match.winnerId === match.player1Id 
                                ? "bg-blue-900/30 text-blue-300 border border-blue-400/40" 
                                : "bg-purple-900/30 text-purple-300 border border-purple-400/40"
                            )}>
                              {winner?.name}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setSelectedMatch(match);
                                setShowMatchDetailsDialog(true);
                              }}
                              className="hover:bg-blue-800/20 text-blue-300"
                              title="View details"
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
              
              {maxPage > 1 && (
                <div className="mt-4">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => setPage(Math.max(1, page - 1))}
                          className={cn(
                            "border-blue-500/30 futuristic-bold", 
                            page === 1 ? "pointer-events-none opacity-50" : "hover:bg-blue-800/20 hover:text-blue-200"
                          )}
                        />
                      </PaginationItem>
                      
                      {Array.from({length: Math.min(maxPage, 5)}).map((_, i) => {
                        let pageNumber;
                        if (maxPage <= 5) {
                          pageNumber = i + 1;
                        } else if (page <= 3) {
                          pageNumber = i + 1;
                        } else if (page >= maxPage - 2) {
                          pageNumber = maxPage - 4 + i;
                        } else {
                          pageNumber = page - 2 + i;
                        }
                        
                        if (pageNumber > 0 && pageNumber <= maxPage) {
                          return (
                            <PaginationItem key={pageNumber}>
                              <PaginationLink
                                isActive={page === pageNumber}
                                onClick={() => setPage(pageNumber)}
                                className={page === pageNumber ? 
                                  "bg-blue-800/40 text-blue-100 border-blue-400/50 neon-border" : 
                                  "border-blue-500/30 hover:bg-blue-800/20 hover:text-blue-200 tech-font"
                                }
                              >
                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }
                        return null;
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => setPage(Math.min(maxPage, page + 1))}
                          className={cn(
                            "border-blue-500/30 futuristic-bold", 
                            page === maxPage ? "pointer-events-none opacity-50" : "hover:bg-blue-800/20 hover:text-blue-200"
                          )}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={showRecordMatchDialog} onOpenChange={setShowRecordMatchDialog}>
        <DialogContent className="bg-blue-950 border border-blue-500/30 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-blue-100 text-lg">Record Match</DialogTitle>
            <DialogDescription className="text-blue-300/70">
              Enter the match details below.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2 text-blue-100">
            <div className="space-y-2">
              <label className="text-sm font-medium futuristic-bold">Game Type</label>
              <Select
                value={selectedGameType}
                onValueChange={setSelectedGameType}
              >
                <SelectTrigger className="border-blue-500/30 bg-blue-900/20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-blue-950 border border-blue-500/30">
                  <SelectItem value="8ball" className="tech-font">8-Ball</SelectItem>
                  <SelectItem value="9ball" className="tech-font">9-Ball</SelectItem>
                  <SelectItem value="10ball" className="tech-font">10-Ball</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium futuristic-bold">Player 1</label>
              <Select
                value={selectedPlayer1?.toString() || ""}
                onValueChange={(value) => setSelectedPlayer1(parseInt(value))}
              >
                <SelectTrigger className="border-blue-500/30 bg-blue-900/20">
                  <SelectValue placeholder="Select player" />
                </SelectTrigger>
                <SelectContent className="bg-blue-950 border border-blue-500/30 max-h-[300px]">
                  {players.map((player) => (
                    <SelectItem 
                      key={player.id} 
                      value={player.id.toString()} 
                      className="tech-font"
                      disabled={selectedPlayer2 === player.id}
                    >
                      {player.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium futuristic-bold">Player 2</label>
              <Select
                value={selectedPlayer2?.toString() || ""}
                onValueChange={(value) => setSelectedPlayer2(parseInt(value))}
              >
                <SelectTrigger className="border-blue-500/30 bg-blue-900/20">
                  <SelectValue placeholder="Select player" />
                </SelectTrigger>
                <SelectContent className="bg-blue-950 border border-blue-500/30 max-h-[300px]">
                  {players.map((player) => (
                    <SelectItem 
                      key={player.id} 
                      value={player.id.toString()} 
                      className="tech-font"
                      disabled={selectedPlayer1 === player.id}
                    >
                      {player.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex gap-4">
              <div className="space-y-2 flex-1">
                <label className="text-sm font-medium futuristic-bold">Player 1 Score</label>
                <Input 
                  type="number" 
                  min="0"
                  className="border-blue-500/30 bg-blue-900/20 text-blue-100"
                  value={player1Score}
                  onChange={(e) => setPlayer1Score(parseInt(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-2 flex-1">
                <label className="text-sm font-medium futuristic-bold">Player 2 Score</label>
                <Input 
                  type="number"
                  min="0"
                  className="border-blue-500/30 bg-blue-900/20 text-blue-100"
                  value={player2Score}
                  onChange={(e) => setPlayer2Score(parseInt(e.target.value) || 0)}
                />
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRecordMatchDialog(false)}
              className="border-blue-500/30 hover:bg-blue-800/20 hover:text-blue-200"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                if (!selectedPlayer1 || !selectedPlayer2) {
                  toast({
                    title: "Missing players",
                    description: "Please select both players.",
                    variant: "destructive"
                  });
                  return;
                }
                
                if (player1Score === 0 && player2Score === 0) {
                  toast({
                    title: "Invalid score",
                    description: "At least one player must have a score greater than zero.",
                    variant: "destructive"
                  });
                  return;
                }
                
                recordMatchMutation.mutate({
                  player1Id: selectedPlayer1,
                  player2Id: selectedPlayer2,
                  player1Score,
                  player2Score,
                  gameType: selectedGameType
                });
              }}
              disabled={recordMatchMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {recordMatchMutation.isPending ? "Recording..." : "Record Match"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={showMatchDetailsDialog} onOpenChange={setShowMatchDetailsDialog}>
        <DialogContent className="bg-blue-950 border border-blue-500/30 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-blue-100 text-lg">Match Details</DialogTitle>
          </DialogHeader>
          
          {selectedMatch && (
            <div className="space-y-4 py-2">
              <div className="flex justify-between items-center border-b border-blue-500/30 pb-2">
                <div className="text-blue-300 tech-font text-sm">Match ID</div>
                <div className="text-blue-100 tech-font text-sm">#{selectedMatch.id}</div>
              </div>
              
              <div className="flex justify-between items-center border-b border-blue-500/30 pb-2">
                <div className="text-blue-300 tech-font text-sm">Date</div>
                <div className="text-blue-100 tech-font text-sm">
                  {format(new Date(selectedMatch.date), "MMMM d, yyyy")}
                </div>
              </div>
              
              <div className="flex justify-between items-center border-b border-blue-500/30 pb-2">
                <div className="text-blue-300 tech-font text-sm">Game Type</div>
                <Badge variant="outline" className="bg-blue-900/30 text-blue-200 border-blue-500/40 futuristic-bold">
                  {selectedMatch.gameType}
                </Badge>
              </div>
              
              <div className="border border-blue-500/30 rounded-md p-4 bg-blue-900/10">
                <div className="flex justify-between mb-3">
                  <div className="text-blue-100 font-semibold player-name">
                    {getPlayerName(selectedMatch.player1Id)}
                  </div>
                  <div className="text-blue-100 font-semibold player-name">
                    {getPlayerName(selectedMatch.player2Id)}
                  </div>
                </div>
                
                <div className="flex justify-center items-center mb-3">
                  <div className="flex-1 text-center text-2xl font-bold text-blue-100 futuristic-bold">
                    {selectedMatch.player1Score}
                  </div>
                  <div className="text-blue-300 mx-2">-</div>
                  <div className="flex-1 text-center text-2xl font-bold text-blue-100 futuristic-bold">
                    {selectedMatch.player2Score}
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="text-sm text-blue-300/70 mb-1 tech-font">Winner</div>
                  <Badge className={cn(
                    "futuristic-bold",
                    selectedMatch.winnerId === selectedMatch.player1Id 
                      ? "bg-blue-900/30 text-blue-300 border border-blue-400/40" 
                      : "bg-purple-900/30 text-purple-300 border border-purple-400/40"
                  )}>
                    {getPlayerName(selectedMatch.winnerId)}
                  </Badge>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              onClick={() => setShowMatchDetailsDialog(false)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, Trophy, Info, Check, Swords, ArrowUpRight, Star } from "lucide-react";
import { cn } from "@/lib/utils";

type Notification = {
  id: number;
  playerId: number;
  type: "challenge" | "result" | "tournament" | "rankChange";
  message: string;
  read: boolean;
  sentEmail: boolean;
  relatedId: number | null;
  createdAt: string;
};

interface NotificationsPanelProps {
  playerId: number;
}

export function NotificationsPanel({ playerId }: NotificationsPanelProps) {
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: [`/api/players/${playerId}/notifications`],
    enabled: !!playerId,
  });

  const markAsRead = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/notifications/${id}/read`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/players/${playerId}/notifications`] });
    },
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "challenge":
        return <Swords className="h-5 w-5 text-blue-500" />;
      case "result":
        return <Trophy className="h-5 w-5 text-amber-500" />;
      case "tournament":
        return <Trophy className="h-5 w-5 text-purple-500" />;
      case "rankChange":
        return <Star className="h-5 w-5 text-green-500" />;
      default:
        return <Info className="h-5 w-5 text-gray-500" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.abs(now.getTime() - date.getTime()) / 36e5;
    
    if (diffInHours < 24) {
      return new Intl.RelativeTimeFormat('en', { style: 'long' }).format(
        -Math.floor(diffInHours), 'hour'
      );
    } else if (diffInHours < 48) {
      return 'yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl">
          <div className="flex items-center">
            <Bell className="h-5 w-5 mr-2" />
            Notifications
            {unreadCount > 0 && (
              <Badge className="ml-2" variant="default">
                {unreadCount} new
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Bell className="h-10 w-10 text-muted-foreground/50 mb-2" />
            <p className="text-muted-foreground">No notifications yet</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px]">
            <div className="space-y-4">
              {notifications.map((notification) => (
                <div 
                  key={notification.id}
                  className={cn(
                    "p-3 rounded-lg border flex items-start gap-3 relative",
                    notification.read 
                      ? "bg-background" 
                      : "bg-muted/50 border-primary/20"
                  )}
                >
                  <div className="p-2 rounded-full bg-muted">
                    {getTypeIcon(notification.type)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <div className="font-medium">
                        {notification.type === "challenge" && "Challenge"}
                        {notification.type === "result" && "Match Result"}
                        {notification.type === "tournament" && "Tournament"}
                        {notification.type === "rankChange" && "Rank Change"}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(notification.createdAt)}
                      </span>
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {notification.message}
                    </p>
                    
                    {!notification.read && (
                      <div className="mt-2 flex justify-end">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          className="h-7 px-2"
                          onClick={() => markAsRead.mutate(notification.id)}
                        >
                          <Check className="h-3 w-3 mr-1" />
                          Mark as read
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}

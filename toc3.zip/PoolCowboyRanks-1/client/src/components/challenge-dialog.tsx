import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Player } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Swords } from "lucide-react";

const gameTypes = ["8ball", "9ball", "10ball"] as const;
const gamesToWin = [1, 2, 3, 4, 5] as const;

const formSchema = z.object({
  defenderId: z.number(),
  gameType: z.enum(gameTypes),
  gamesToWin: z.number().min(1).max(5),
});

type FormValues = z.infer<typeof formSchema>;

interface ChallengeDialogProps {
  player: Player | null;
  onClose: () => void;
  players: Player[];
}

export function ChallengeDialog({ player, onClose, players }: ChallengeDialogProps) {
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      defenderId: player?.id,
      gameType: "8ball",
      gamesToWin: 1,
    },
  });

  const createChallenge = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest("POST", "/api/challenges", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/challenges"] });
      toast({
        title: "Challenge created",
        description: "Your challenge has been sent successfully.",
      });
      onClose();
    },
  });

  function onSubmit(data: FormValues) {
    createChallenge.mutate(data);
  }

  return (
    <Dialog open={!!player} onOpenChange={() => onClose()}>
      <DialogContent className="player-card sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <Swords className="h-6 w-6 text-primary" />
            Issue Challenge
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="gameType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg">Game Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="border-primary/50">
                        <SelectValue placeholder="Select game type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {gameTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type.charAt(0).toUpperCase() + type.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="gamesToWin"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-lg">Games to Win</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value.toString()}
                  >
                    <FormControl>
                      <SelectTrigger className="border-primary/50">
                        <SelectValue placeholder="Select number of games" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {gamesToWin.map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          First to {num}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-2 pt-4">
              <Button 
                variant="outline" 
                onClick={onClose}
                className="border-primary/50 hover:bg-primary/20"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createChallenge.isPending}
                className="bg-primary hover:bg-primary/80"
              >
                Send Challenge
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
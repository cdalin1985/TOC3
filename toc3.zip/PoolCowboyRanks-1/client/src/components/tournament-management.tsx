
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { CalendarIcon, ChevronsUpDown, Trophy, Users, Medal, Calendar as CalendarIcon2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Player, Tournament } from "@shared/schema";

export function TournamentManagement() {
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [formValues, setFormValues] = useState({
    name: "",
    gameType: "8ball",
    format: "singleElimination",
    startDate: new Date(),
    endDate: null,
    description: "",
    maxPlayers: "16",
  });
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<string>("");

  const { data: tournaments = [] } = useQuery<Tournament[]>({
    queryKey: ["/api/tournaments"],
  });

  const { data: players = [] } = useQuery<Player[]>({
    queryKey: ["/api/players"],
  });

  const createTournament = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/tournaments", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      setIsCreateOpen(false);
      toast({
        title: "Tournament created",
        description: "The tournament has been created successfully.",
      });
      // Reset form
      setFormValues({
        name: "",
        gameType: "8ball",
        format: "singleElimination",
        startDate: new Date(),
        endDate: null,
        description: "",
        maxPlayers: "16",
      });
    },
  });

  const registerPlayer = useMutation({
    mutationFn: async (data: { playerId: number; tournamentId: number }) => {
      const res = await apiRequest("POST", `/api/tournaments/${data.tournamentId}/players`, {
        playerId: data.playerId,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      setIsRegisterOpen(false);
      toast({
        title: "Player registered",
        description: "The player has been registered for the tournament.",
      });
      setSelectedPlayer("");
    },
  });

  const updateTournamentStatus = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await apiRequest("POST", `/api/tournaments/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      toast({
        title: "Tournament updated",
        description: "The tournament status has been updated.",
      });
    },
  });

  const generateBrackets = useMutation({
    mutationFn: async (tournamentId: number) => {
      const res = await apiRequest("POST", `/api/tournaments/${tournamentId}/generate`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tournaments"] });
      toast({
        title: "Brackets generated",
        description: "The tournament brackets have been generated.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    createTournament.mutate({
      name: formValues.name,
      gameType: formValues.gameType,
      format: formValues.format,
      startDate: formValues.startDate,
      endDate: formValues.endDate,
      description: formValues.description,
      maxPlayers: parseInt(formValues.maxPlayers),
    });
  };

  const handleRegister = () => {
    if (!selectedPlayer || !selectedTournament) return;
    
    registerPlayer.mutate({
      playerId: parseInt(selectedPlayer),
      tournamentId: selectedTournament.id,
    });
  };

  const activeTournaments = tournaments.filter(t => t.status === "active");
  const upcomingTournaments = tournaments.filter(t => t.status === "upcoming");
  const completedTournaments = tournaments.filter(t => t.status === "completed");

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "MMM d, yyyy");
  };

  const getTournamentStatusColor = (status: string) => {
    switch (status) {
      case "upcoming": return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300";
      case "active": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300";
      case "completed": return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300";
      default: return "";
    }
  };

  const renderTournamentDetails = (tournament: Tournament) => {
    const { data: details } = useQuery({
      queryKey: [`/api/tournaments/${tournament.id}`],
      enabled: !!tournament,
    });

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium">{tournament.name}</h3>
            <p className="text-sm text-muted-foreground">
              {formatDate(tournament.startDate)} - {tournament.endDate ? formatDate(tournament.endDate) : "TBD"}
            </p>
          </div>
          <Badge className={cn("ml-2", getTournamentStatusColor(tournament.status))}>
            {tournament.status}
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium mb-2">Format</h4>
            <p className="text-sm">
              {tournament.format === "singleElimination" && "Single Elimination"}
              {tournament.format === "doubleElimination" && "Double Elimination"}
              {tournament.format === "roundRobin" && "Round Robin"}
            </p>
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Game Type</h4>
            <p className="text-sm">{tournament.gameType}</p>
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium mb-2">Description</h4>
          <p className="text-sm">{tournament.description || "No description provided."}</p>
        </div>
        
        <Separator />
        
        <div>
          <h4 className="text-sm font-medium mb-2 flex items-center">
            <Users className="h-4 w-4 mr-1" /> Registered Players
          </h4>
          
          {details?.players?.length > 0 ? (
            <div className="max-h-40 overflow-y-auto">
              <Table>
                <TableBody>
                  {details.players.map((player: any) => {
                    const playerDetails = players.find(p => p.id === player.playerId);
                    return (
                      <TableRow key={player.id}>
                        <TableCell>{playerDetails?.name || `Player #${player.playerId}`}</TableCell>
                        <TableCell className="text-right">
                          <Badge variant="outline">{player.status}</Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No players registered yet.</p>
          )}
        </div>
        
        {details?.matches?.length > 0 && (
          <>
            <Separator />
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <Trophy className="h-4 w-4 mr-1" /> Matches
              </h4>
              <div className="max-h-60 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Round</TableHead>
                      <TableHead>Players</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Result</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {details.matches.map((match: any) => {
                      const player1 = players.find(p => p.id === match.player1Id);
                      const player2 = players.find(p => p.id === match.player2Id);
                      
                      return (
                        <TableRow key={match.id}>
                          <TableCell>{match.round}</TableCell>
                          <TableCell>
                            {player1?.name || "TBD"} vs. {player2?.name || "TBD"}
                          </TableCell>
                          <TableCell>
                            <Badge variant={match.status === "completed" ? "default" : "outline"}>
                              {match.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{match.score || "-"}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </div>
          </>
        )}
        
        {tournament.status === "upcoming" && (
          <div className="flex justify-end space-x-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setSelectedTournament(tournament);
                setIsRegisterOpen(true);
              }}
            >
              Register Player
            </Button>
            <Button 
              onClick={() => generateBrackets.mutate(tournament.id)}
              disabled={generateBrackets.isPending}
            >
              Generate Brackets
            </Button>
          </div>
        )}
        
        {tournament.status === "active" && (
          <div className="flex justify-end">
            <Button 
              onClick={() => updateTournamentStatus.mutate({
                id: tournament.id,
                status: "completed"
              })}
              variant="outline"
            >
              Complete Tournament
            </Button>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Tournament Management</h2>
        <Button onClick={() => setIsCreateOpen(true)}>
          Create Tournament
        </Button>
      </div>
      
      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">
            Active <Badge variant="outline" className="ml-2">{activeTournaments.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="upcoming">
            Upcoming <Badge variant="outline" className="ml-2">{upcomingTournaments.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed <Badge variant="outline" className="ml-2">{completedTournaments.length}</Badge>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-4">
          {activeTournaments.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No active tournaments at the moment.
              </CardContent>
            </Card>
          ) : (
            activeTournaments.map(tournament => (
              <Card key={tournament.id}>
                <CardContent className="pt-6">
                  {renderTournamentDetails(tournament)}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="upcoming" className="space-y-4">
          {upcomingTournaments.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No upcoming tournaments scheduled.
              </CardContent>
            </Card>
          ) : (
            upcomingTournaments.map(tournament => (
              <Card key={tournament.id}>
                <CardContent className="pt-6">
                  {renderTournamentDetails(tournament)}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="completed" className="space-y-4">
          {completedTournaments.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                No completed tournaments.
              </CardContent>
            </Card>
          ) : (
            completedTournaments.map(tournament => (
              <Card key={tournament.id}>
                <CardContent className="pt-6">
                  {renderTournamentDetails(tournament)}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
      
      {/* Create Tournament Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create Tournament</DialogTitle>
            <DialogDescription>
              Create a new tournament for players to participate in.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Tournament Name</Label>
                <Input
                  id="name"
                  placeholder="Summer Championship"
                  value={formValues.name}
                  onChange={(e) => setFormValues({ ...formValues, name: e.target.value })}
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="gameType">Game Type</Label>
                  <Select
                    value={formValues.gameType}
                    onValueChange={(value) => setFormValues({ ...formValues, gameType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select game type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="8ball">8-Ball</SelectItem>
                      <SelectItem value="9ball">9-Ball</SelectItem>
                      <SelectItem value="10ball">10-Ball</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="format">Format</Label>
                  <Select
                    value={formValues.format}
                    onValueChange={(value) => setFormValues({ ...formValues, format: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="singleElimination">Single Elimination</SelectItem>
                      <SelectItem value="doubleElimination">Double Elimination</SelectItem>
                      <SelectItem value="roundRobin">Round Robin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Start Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formValues.startDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formValues.startDate ? format(formValues.startDate, "PPP") : "Pick a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formValues.startDate}
                        onSelect={(date) => setFormValues({ ...formValues, startDate: date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="grid gap-2">
                  <Label>End Date (Optional)</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !formValues.endDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {formValues.endDate ? format(formValues.endDate, "PPP") : "Pick a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={formValues.endDate}
                        onSelect={(date) => setFormValues({ ...formValues, endDate: date })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="maxPlayers">Maximum Players</Label>
                <Input
                  id="maxPlayers"
                  type="number"
                  min="2"
                  placeholder="16"
                  value={formValues.maxPlayers}
                  onChange={(e) => setFormValues({ ...formValues, maxPlayers: e.target.value })}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Tournament details, rules, prizes, etc."
                  value={formValues.description}
                  onChange={(e) => setFormValues({ ...formValues, description: e.target.value })}
                  rows={4}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsCreateOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={createTournament.isPending}>
                {createTournament.isPending ? "Creating..." : "Create Tournament"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Register Player Dialog */}
      <Dialog open={isRegisterOpen} onOpenChange={setIsRegisterOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Register Player</DialogTitle>
            <DialogDescription>
              Add a player to {selectedTournament?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="player">Select Player</Label>
              <Select
                value={selectedPlayer}
                onValueChange={setSelectedPlayer}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a player" />
                </SelectTrigger>
                <SelectContent>
                  {players.map((player) => (
                    <SelectItem key={player.id} value={player.id.toString()}>
                      {player.name} (Rank: {player.rank})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsRegisterOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleRegister}
              disabled={!selectedPlayer || registerPlayer.isPending}
            >
              {registerPlayer.isPending ? "Registering..." : "Register"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { Input, InputProps } from "@/components/ui/input";
import { cn } from "@/lib/utils";

// Format phone number with (xxx) xxx-xxxx pattern
function formatPhoneNumber(value: string): string {
  if (!value) return value;

  // Remove all non-numeric characters
  const phoneNumber = value.replace(/[^\d]/g, "");
  const phoneNumberLength = phoneNumber.length;

  // Return if it's empty
  if (phoneNumberLength < 1) return "";

  // Format based on the length
  if (phoneNumberLength < 4) {
    return `(${phoneNumber}`;
  } else if (phoneNumberLength < 7) {
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(3)}`;
  } else {
    return `(${phoneNumber.slice(0, 3)}) ${phoneNumber.slice(
      3,
      6
    )}-${phoneNumber.slice(6, 10)}`;
  }
}

// Parse phone number by removing formatting characters
function parsePhoneNumber(formattedNumber: string): string {
  if (!formattedNumber) return "";
  return formattedNumber.replace(/[^\d]/g, "");
}

export interface PhoneInputProps extends Omit<InputProps, "onChange"> {
  value: string;
  onChange: (value: string) => void;
  storeRawValue?: boolean;
}

export function PhoneInput({
  value,
  onChange,
  storeRawValue = false,
  className,
  ...props
}: PhoneInputProps) {
  // Internal formatted state for display
  const [displayValue, setDisplayValue] = useState("");

  // Update display value when external value changes
  useEffect(() => {
    if (storeRawValue) {
      setDisplayValue(formatPhoneNumber(value));
    } else {
      setDisplayValue(value);
    }
  }, [value, storeRawValue]);

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    const formattedValue = formatPhoneNumber(inputValue);
    
    // Update internal state
    setDisplayValue(formattedValue);
    
    // Send back raw or formatted value based on storeRawValue prop
    const outputValue = storeRawValue ? parsePhoneNumber(formattedValue) : formattedValue;
    onChange(outputValue);
  };

  return (
    <Input
      type="tel"
      value={displayValue}
      onChange={handleInputChange}
      className={cn("phone-input", className)}
      maxLength={14} // (xxx) xxx-xxxx = 14 characters
      {...props}
    />
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Player } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Trophy, Award, Target, Swords, ChevronDown, ChevronUp } from "lucide-react";
import { Skeleton } from "./ui/skeleton";

interface PlayerStatistics {
  player: Player;
  matches: number;
  challenges: number;
  winPercentage: string;
  gameTypes: Record<string, number>;
  mostPlayedOpponent: string;
  recentMatches: any[];
}

export function StatisticsDashboard({ playerId }: { playerId: number }) {
  const { data: statistics, isLoading } = useQuery<PlayerStatistics>({
    queryKey: [`/api/players/${playerId}/statistics`],
    enabled: !!playerId,
  });

  const { data: matches = [] } = useQuery({
    queryKey: [`/api/players/${playerId}/matches`],
    enabled: !!playerId,
  });

  const formatGameTypeData = () => {
    if (!statistics?.gameTypes) return [];
    return Object.entries(statistics.gameTypes).map(([name, count]) => ({
      name,
      count,
    }));
  };

  if (isLoading) {
    return (
      <Card className="col-span-3">
        <CardHeader>
          <CardTitle>
            <Skeleton className="h-8 w-64" />
          </CardTitle>
          <CardDescription>
            <Skeleton className="h-4 w-48" />
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!statistics) return null;

  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle className="text-2xl">Player Statistics Dashboard</CardTitle>
        <CardDescription>Detailed performance metrics for {statistics.player.name}</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="matches">Match History</TabsTrigger>
            <TabsTrigger value="trends">Performance Trends</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
                  <Trophy className="h-4 w-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{statistics.winPercentage}%</div>
                  <Progress 
                    value={parseFloat(statistics.winPercentage)} 
                    className="mt-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {statistics.player.wins} wins / {statistics.player.losses} losses
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Current Rank</CardTitle>
                  <Award className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{statistics.player.rank}</div>
                  <div className="text-xs text-muted-foreground mt-3">
                    {statistics.player.rank === 1 ? (
                      <div className="flex items-center text-green-600">
                        <Trophy className="h-3 w-3 mr-1" />
                        Top Position
                      </div>
                    ) : (
                      <div className="flex items-center text-blue-600">
                        <ChevronUp className="h-3 w-3 mr-1" />
                        {statistics.player.rank - 1} to reach top
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Matches</CardTitle>
                  <Swords className="h-4 w-4 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{statistics.matches}</div>
                  <div className="text-xs text-muted-foreground mt-3">
                    {statistics.challenges} challenges issued/received
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fargo Rating</CardTitle>
                  <Target className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{statistics.player.fargoRating || "N/A"}</div>
                  <div className="text-xs text-muted-foreground mt-3">
                    Most played against: {statistics.mostPlayedOpponent}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>Games Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={formatGameTypeData()}>
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar 
                        dataKey="count" 
                        fill="#8884d8" 
                        radius={[4, 4, 0, 0]} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {statistics.recentMatches.length === 0 ? (
                    <p className="text-center text-muted-foreground py-10">
                      No recent matches found
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {statistics.recentMatches.map((match) => (
                        <div 
                          key={match.id} 
                          className={`flex items-center justify-between p-2 rounded-md ${
                            match.winnerId === statistics.player.id 
                              ? "bg-green-100 dark:bg-green-900/20" 
                              : "bg-red-100 dark:bg-red-900/20"
                          }`}
                        >
                          <div>
                            <span>{match.gameType}</span> 
                            <span className="ml-2 text-sm text-muted-foreground">
                              {new Date(match.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div>
                            {match.winnerId === statistics.player.id ? (
                              <Trophy className="h-4 w-4 text-green-600" />
                            ) : (
                              <ChevronDown className="h-4 w-4 text-red-600" />
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="matches">
            <Card>
              <CardHeader>
                <CardTitle>Match History</CardTitle>
              </CardHeader>
              <CardContent>
                {matches.length === 0 ? (
                  <p className="text-center text-muted-foreground py-10">
                    No match history found
                  </p>
                ) : (
                  <div className="space-y-2">
                    {matches.map((match: any) => (
                      <div 
                        key={match.id} 
                        className="border rounded-md p-3 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-medium">
                            {match.player1Id === statistics.player.id 
                              ? "You vs. Opponent" 
                              : "Opponent vs. You"}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {match.gameType} | {new Date(match.date).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="text-xl font-bold">
                          {match.player1Id === statistics.player.id 
                            ? `${match.player1Score} - ${match.player2Score}`
                            : `${match.player2Score} - ${match.player1Score}`}
                        </div>
                        <div className={match.winnerId === statistics.player.id 
                          ? "text-green-600 font-medium" 
                          : "text-red-600 font-medium"}
                        >
                          {match.winnerId === statistics.player.id ? "WIN" : "LOSS"}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="trends">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
              </CardHeader>
              <CardContent className="h-96">
                <p className="text-center text-muted-foreground py-10">
                  Performance trend analysis will be available when more match data is gathered.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

import { pgTable, text, serial, integer, boolean, timestamp, date, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  email: text("email"), // No longer used - kept for backward compatibility
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userPlayers = pgTable("user_players", {
  userId: integer("user_id").notNull().references(() => users.id),
  playerId: integer("player_id").notNull().references(() => players.id),
}, (table) => {
  return {
    pk: primaryKey({ columns: [table.userId, table.playerId] }),
  };
});

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rank: integer("rank").notNull(),
  fargoRating: integer("fargo_rating"),
  wins: integer("wins").default(0).notNull(),
  losses: integer("losses").default(0).notNull(),
  phoneNumber: text("phone_number"),
  totalGamesPlayed: integer("total_games_played").default(0).notNull(),
  highestRankAchieved: integer("highest_rank_achieved"),
  activeChallenges: integer("active_challenges").default(0).notNull(),
});

export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  challengerId: integer("challenger_id").notNull(),
  defenderId: integer("defender_id").notNull(),
  gameType: text("game_type", { enum: ["8ball", "9ball", "10ball"] }).notNull(),
  gamesToWin: integer("games_to_win").notNull(),
  status: text("status", { enum: ["pending", "accepted", "completed", "rejected"] }).notNull(),
  winnerId: integer("winner_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  challengeId: integer("challenge_id").notNull(),
  player1Id: integer("player1_id").notNull(),
  player2Id: integer("player2_id").notNull(),
  player1Score: integer("player1_score").notNull(),
  player2Score: integer("player2_score").notNull(),
  winnerId: integer("winner_id").notNull(),
  gameType: text("game_type", { enum: ["8ball", "9ball", "10ball"] }).notNull(),
  date: timestamp("date").defaultNow().notNull(),
});

export const tournaments = pgTable("tournaments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  status: text("status", { enum: ["upcoming", "active", "completed"] }).default("upcoming").notNull(),
  gameType: text("game_type", { enum: ["8ball", "9ball", "10ball"] }).notNull(),
  description: text("description"),
  maxPlayers: integer("max_players"),
  format: text("format", { enum: ["singleElimination", "doubleElimination", "roundRobin"] }).notNull(),
});

export const tournamentPlayers = pgTable("tournament_players", {
  id: serial("id").primaryKey(),
  tournamentId: integer("tournament_id").notNull(),
  playerId: integer("player_id").notNull(),
  seedNumber: integer("seed_number"),
  status: text("status", { enum: ["registered", "active", "eliminated", "winner"] }).default("registered").notNull(),
});

export const tournamentMatches = pgTable("tournament_matches", {
  id: serial("id").primaryKey(),
  tournamentId: integer("tournament_id").notNull(),
  round: integer("round").notNull(),
  player1Id: integer("player1_id"),
  player2Id: integer("player2_id"),
  winnerId: integer("winner_id"),
  score: text("score"),
  matchNumber: integer("match_number").notNull(),
  status: text("status", { enum: ["scheduled", "completed"] }).default("scheduled").notNull(),
  date: timestamp("date"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull(),
  type: text("type", { enum: ["challenge", "result", "tournament", "rankChange"] }).notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false).notNull(),
  sentEmail: boolean("sent_email").default(false).notNull(),
  relatedId: integer("related_id"), // Could be challengeId, tournamentId, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  name: true,
  rank: true,
  fargoRating: true,
  phoneNumber: true,
});

export const insertChallengeSchema = createInsertSchema(challenges).pick({
  challengerId: true,
  defenderId: true,
  gameType: true,
  gamesToWin: true,
});

export const insertMatchSchema = createInsertSchema(matches).pick({
  challengeId: true,
  player1Id: true,
  player2Id: true,
  player1Score: true,
  player2Score: true,
  winnerId: true,
  gameType: true,
});

export const insertTournamentSchema = createInsertSchema(tournaments).pick({
  name: true,
  startDate: true,
  endDate: true,
  gameType: true,
  description: true,
  maxPlayers: true,
  format: true,
});

export const insertTournamentPlayerSchema = createInsertSchema(tournamentPlayers).pick({
  tournamentId: true,
  playerId: true,
  seedNumber: true,
});

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;
export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Tournament = typeof tournaments.$inferSelect;
export type InsertTournament = z.infer<typeof insertTournamentSchema>;
export type TournamentPlayer = typeof tournamentPlayers.$inferSelect;
export type InsertTournamentPlayer = z.infer<typeof insertTournamentPlayerSchema>;
export type TournamentMatch = typeof tournamentMatches.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type User = typeof users.$inferSelect;
export type UserPlayer = typeof userPlayers.$inferSelect;

export const insertUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(6),
  accountType: z.enum(['player', 'guest']),
  playerId: z.number().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage } from "./storage";
import passport from "passport";
import session from "express-session";
import memorystore from "memorystore";
import cors from "cors";
import { configurePassport, registerAuthRoutes } from "./auth";

const MemoryStore = memorystore(session);

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(cors({ 
  origin: true,
  credentials: true
}));


app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Configure session
app.use(session({
  cookie: { maxAge: 86400000 }, // 24 hours
  store: new MemoryStore({
    checkPeriod: 86400000 // prune expired entries every 24h
  }),
  resave: false,
  saveUninitialized: false,
  secret: process.env.SESSION_SECRET || 'top-of-the-capital-pool-session-secret'
}));

// Configure passport
app.use(passport.initialize());
app.use(passport.session());
configurePassport();

(async () => {
  // Check if we need to populate initial players
  const players = await storage.getPlayers();
  if (players.length === 0) {
    const initialPlayers = [
      { name: "Dan Hamper", rank: 1 },
      { name: "David Smith", rank: 2 },
      { name: "David Alderman", rank: 3 },
      { name: "Frank Kincl", rank: 4 },
      { name: "Mike Paliga", rank: 5 },
      { name: "Chase Dalin", rank: 6 },
      { name: "Timmy Squires", rank: 7 },
      { name: "Tim Webster", rank: 8 },
      { name: "Eric Croft", rank: 9 },
      { name: "Louise Broksle", rank: 10 },
      { name: "Jerry Sabol", rank: 11 },
      { name: "Joel Selzer", rank: 12 },
      { name: "Thomas E. Kingston", rank: 13 },
      { name: "Chris Gomez", rank: 14 },
      { name: "Josh Fava", rank: 15 },
      { name: "Kurt Kubicka", rank: 16 },
      { name: "Mike Churchill", rank: 17 },
      { name: "George Cotton", rank: 18 },
      { name: "Vern Carpenter", rank: 19 },
      { name: "Mike Zahn", rank: 20 },
      { name: "Matt Gilbert", rank: 21 },
      { name: "Gurn Blanston", rank: 22 },
      { name: "Rob Millions", rank: 23 },
      { name: "Janice Osborne", rank: 24 },
      { name: "Patrick Donald", rank: 25 },
      { name: "Tim Gregor", rank: 26 },
      { name: "James McMasters", rank: 27 },
      { name: "Walker Hopkins", rank: 28 },
      { name: "Joe Mackay", rank: 29 },
      { name: "Anthony Jacobs", rank: 30 },
      { name: "Steve Adsem", rank: 31 },
      { name: "Keith Cook", rank: 32 },
      { name: "Samantha Chase", rank: 33 },
      { name: "Lea Hightshoe", rank: 34 },
      { name: "Courtney Norman", rank: 35 },
      { name: "Marc Sanche", rank: 36 },
      { name: "Roger Simmons", rank: 37 },
      { name: "Christina Talbot", rank: 38 },
      { name: "Jon Nash", rank: 39 },
      { name: "Sady Garrison", rank: 40 },
      { name: "Justin Cavazos", rank: 41 },
      { name: "Sean Royston", rank: 42 },
      { name: "Mean Kelly Dean", rank: 43 },
      { name: "James Smith", rank: 44 },
      { name: "Zach Ledesma", rank: 45 },
      { name: "Clayton Carter", rank: 46 },
      { name: "Ryan Fields", rank: 47 },
      { name: "Kris Vladic", rank: 48 },
      { name: "Bill Nelson", rank: 49 },
      { name: "Robert Glueckert", rank: 50 },
      { name: "Nate Welch", rank: 51 },
      { name: "Josh Hill", rank: 52 },
      { name: "Jennifer Lynn", rank: 53 },
      { name: "Walter Ryan Isenhour", rank: 54 },
      { name: "Steven Ross Brandenburg", rank: 55 },
      { name: "Heather Jarvis", rank: 56 },
      { name: "Craig Rogers", rank: 57 },
      { name: "Tizer Rushford", rank: 58 },
      { name: "Josh Waples", rank: 59 },
      { name: "Jesse Chandler", rank: 60 },
      { name: "Kenrick Leistiko", rank: 61 },
      { name: "Richard Frankforter", rank: 62 },
      { name: "Troy Jacobs", rank: 63 },
      { name: "Brandon Lucas Parker", rank: 64 },
      { name: "James Ellington", rank: 65 },
      { name: "Anita Scharf", rank: 66 },
      { name: "Ileana Hernandez", rank: 67 }
    ];

    for (const player of initialPlayers) {
      await storage.createPlayer({
        name: player.name,
        rank: player.rank,
        fargoRating: null
      });
    }
    log("Initial players populated successfully!");
  }

  const server = await registerRoutes(app);
  registerAuthRoutes(app); // Added authentication route registration

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
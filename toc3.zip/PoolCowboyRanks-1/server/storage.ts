import { 
  type Player, 
  type InsertPlayer, 
  type Challenge, 
  type InsertChallenge,
  type Match,
  type InsertMatch,
  type Tournament,
  type InsertTournament,
  type TournamentPlayer,
  type InsertTournamentPlayer,
  type TournamentMatch,
  type Notification
} from "@shared/schema";

export interface IStorage {
  // Player operations
  getPlayers(): Promise<Player[]>;
  getPlayer(id: number): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayerRank(id: number, newRank: number): Promise<Player>;
  updatePlayerStats(id: number, won: boolean): Promise<Player>;
  updatePlayerPhoneNumber(id: number, phoneNumber: string): Promise<Player>;
  
  // Challenge operations
  getChallenges(): Promise<Challenge[]>;
  getChallenge(id: number): Promise<Challenge | undefined>;
  getPlayerChallenges(playerId: number): Promise<Challenge[]>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  updateChallengeStatus(id: number, status: Challenge["status"], winnerId?: number): Promise<Challenge>;
  
  // Match operations
  getMatches(): Promise<Match[]>;
  getPlayerMatches(playerId: number): Promise<Match[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  
  // Tournament operations
  getTournaments(): Promise<Tournament[]>;
  getTournament(id: number): Promise<Tournament | undefined>;
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  updateTournamentStatus(id: number, status: Tournament["status"]): Promise<Tournament>;
  
  // Tournament Player operations
  getTournamentPlayers(tournamentId: number): Promise<TournamentPlayer[]>;
  addPlayerToTournament(tournamentPlayer: InsertTournamentPlayer): Promise<TournamentPlayer>;
  updateTournamentPlayerStatus(id: number, status: TournamentPlayer["status"]): Promise<TournamentPlayer>;
  
  // Tournament Match operations
  getTournamentMatches(tournamentId: number): Promise<TournamentMatch[]>;
  createTournamentMatch(match: Partial<TournamentMatch>): Promise<TournamentMatch>;
  updateTournamentMatch(id: number, winnerId: number, score: string): Promise<TournamentMatch>;
  
  // Notification operations
  getPlayerNotifications(playerId: number): Promise<Notification[]>;
  createNotification(notification: Partial<Notification>): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification>;
  markNotificationEmailSent(id: number): Promise<Notification>;
}

export class MemStorage implements IStorage {
  private players: Map<number, Player>;
  private challenges: Map<number, Challenge>;
  private matches: Map<number, Match>;
  private tournaments: Map<number, Tournament>;
  private tournamentPlayers: Map<number, TournamentPlayer>;
  private tournamentMatches: Map<number, TournamentMatch>;
  private notifications: Map<number, Notification>;
  private playerId: number;
  private challengeId: number;
  private matchId: number;
  private tournamentId: number;
  private tournamentPlayerId: number;
  private tournamentMatchId: number;
  private notificationId: number;

  constructor() {
    this.players = new Map();
    this.challenges = new Map();
    this.matches = new Map();
    this.tournaments = new Map();
    this.tournamentPlayers = new Map();
    this.tournamentMatches = new Map();
    this.notifications = new Map();
    this.playerId = 1;
    this.challengeId = 1;
    this.matchId = 1;
    this.tournamentId = 1;
    this.tournamentPlayerId = 1;
    this.tournamentMatchId = 1;
    this.notificationId = 1;
  }

  async getPlayers(): Promise<Player[]> {
    return Array.from(this.players.values()).sort((a, b) => a.rank - b.rank);
  }

  async getPlayer(id: number): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const id = this.playerId++;
    const player: Player = { 
      ...insertPlayer, 
      id,
      wins: 0,
      losses: 0,
      fargoRating: insertPlayer.fargoRating || null,
      phoneNumber: insertPlayer.phoneNumber || null,
      totalGamesPlayed: 0,
      highestRankAchieved: null,
      activeChallenges: 0
    };
    this.players.set(id, player);
    return player;
  }

  async updatePlayerRank(id: number, newRank: number): Promise<Player> {
    const player = this.players.get(id);
    if (!player) throw new Error("Player not found");
    
    const updatedPlayer = { ...player, rank: newRank };
    this.players.set(id, updatedPlayer);
    return updatedPlayer;
  }

  async updatePlayerStats(id: number, won: boolean): Promise<Player> {
    const player = this.players.get(id);
    if (!player) throw new Error("Player not found");
    
    const updatedPlayer = {
      ...player,
      wins: player.wins + (won ? 1 : 0),
      losses: player.losses + (won ? 0 : 1)
    };
    this.players.set(id, updatedPlayer);
    return updatedPlayer;
  }

  async getChallenges(): Promise<Challenge[]> {
    return Array.from(this.challenges.values());
  }

  async getChallenge(id: number): Promise<Challenge | undefined> {
    return this.challenges.get(id);
  }

  async createChallenge(insertChallenge: InsertChallenge): Promise<Challenge> {
    const id = this.challengeId++;
    const challenge: Challenge = {
      ...insertChallenge,
      id,
      status: "pending",
      winnerId: null,
      createdAt: new Date(),
      completedAt: null
    };
    this.challenges.set(id, challenge);
    return challenge;
  }

  async updateChallengeStatus(
    id: number, 
    status: Challenge["status"], 
    winnerId?: number
  ): Promise<Challenge> {
    const challenge = this.challenges.get(id);
    if (!challenge) throw new Error("Challenge not found");
    
    const updatedChallenge = { 
      ...challenge, 
      status,
      winnerId: winnerId || null
    };
    this.challenges.set(id, updatedChallenge);
    return updatedChallenge;
  }

  async updatePlayerPhoneNumber(id: number, phoneNumber: string): Promise<Player> {
    const player = this.players.get(id);
    if (!player) throw new Error("Player not found");
    
    const updatedPlayer = { ...player, phoneNumber };
    this.players.set(id, updatedPlayer);
    return updatedPlayer;
  }

  async getPlayerChallenges(playerId: number): Promise<Challenge[]> {
    return Array.from(this.challenges.values()).filter(
      challenge => challenge.challengerId === playerId || challenge.defenderId === playerId
    );
  }

  async getMatches(): Promise<Match[]> {
    return Array.from(this.matches.values());
  }

  async getPlayerMatches(playerId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      match => match.player1Id === playerId || match.player2Id === playerId
    );
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.matchId++;
    const match: Match = {
      ...insertMatch,
      id,
      date: new Date()
    };
    this.matches.set(id, match);
    return match;
  }

  // Tournament operations
  async getTournaments(): Promise<Tournament[]> {
    return Array.from(this.tournaments.values());
  }

  async getTournament(id: number): Promise<Tournament | undefined> {
    return this.tournaments.get(id);
  }

  async createTournament(insertTournament: InsertTournament): Promise<Tournament> {
    const id = this.tournamentId++;
    // Explicit type casting to ensure proper format
    const tournament: Tournament = {
      id,
      name: insertTournament.name,
      startDate: insertTournament.startDate,
      gameType: insertTournament.gameType,
      format: insertTournament.format,
      status: "upcoming",
      endDate: insertTournament.endDate ?? null,
      description: insertTournament.description ?? null,
      maxPlayers: insertTournament.maxPlayers ?? null
    };
    this.tournaments.set(id, tournament);
    return tournament;
  }

  async updateTournamentStatus(id: number, status: Tournament["status"]): Promise<Tournament> {
    const tournament = this.tournaments.get(id);
    if (!tournament) throw new Error("Tournament not found");
    
    const updatedTournament = { ...tournament, status };
    this.tournaments.set(id, updatedTournament);
    return updatedTournament;
  }

  // Tournament Player operations
  async getTournamentPlayers(tournamentId: number): Promise<TournamentPlayer[]> {
    return Array.from(this.tournamentPlayers.values()).filter(
      player => player.tournamentId === tournamentId
    );
  }

  async addPlayerToTournament(insertTournamentPlayer: InsertTournamentPlayer): Promise<TournamentPlayer> {
    const id = this.tournamentPlayerId++;
    // Explicit type casting to ensure proper format
    const tournamentPlayer: TournamentPlayer = {
      id,
      tournamentId: insertTournamentPlayer.tournamentId,
      playerId: insertTournamentPlayer.playerId,
      status: "registered",
      seedNumber: insertTournamentPlayer.seedNumber ?? null
    };
    this.tournamentPlayers.set(id, tournamentPlayer);
    return tournamentPlayer;
  }

  async updateTournamentPlayerStatus(id: number, status: TournamentPlayer["status"]): Promise<TournamentPlayer> {
    const tournamentPlayer = this.tournamentPlayers.get(id);
    if (!tournamentPlayer) throw new Error("Tournament player not found");
    
    const updatedTournamentPlayer = { ...tournamentPlayer, status };
    this.tournamentPlayers.set(id, updatedTournamentPlayer);
    return updatedTournamentPlayer;
  }

  // Tournament Match operations
  async getTournamentMatches(tournamentId: number): Promise<TournamentMatch[]> {
    return Array.from(this.tournamentMatches.values()).filter(
      match => match.tournamentId === tournamentId
    );
  }

  async createTournamentMatch(matchData: Partial<TournamentMatch>): Promise<TournamentMatch> {
    const id = this.tournamentMatchId++;
    const match: TournamentMatch = {
      id,
      tournamentId: matchData.tournamentId!,
      round: matchData.round!,
      matchNumber: matchData.matchNumber!,
      player1Id: matchData.player1Id || null,
      player2Id: matchData.player2Id || null,
      winnerId: null,
      score: null,
      status: "scheduled",
      date: null
    };
    this.tournamentMatches.set(id, match);
    return match;
  }

  async updateTournamentMatch(id: number, winnerId: number, score: string): Promise<TournamentMatch> {
    const match = this.tournamentMatches.get(id);
    if (!match) throw new Error("Tournament match not found");
    
    const updatedMatch: TournamentMatch = { 
      ...match, 
      winnerId, 
      score, 
      status: "completed" as const,
      date: new Date()
    };
    this.tournamentMatches.set(id, updatedMatch);
    return updatedMatch;
  }

  // Notification operations
  async getPlayerNotifications(playerId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.playerId === playerId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createNotification(notificationData: Partial<Notification>): Promise<Notification> {
    const id = this.notificationId++;
    const notification: Notification = {
      id,
      playerId: notificationData.playerId!,
      type: notificationData.type!,
      message: notificationData.message!,
      read: false,
      sentEmail: false,
      relatedId: notificationData.relatedId || null,
      createdAt: new Date()
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<Notification> {
    const notification = this.notifications.get(id);
    if (!notification) throw new Error("Notification not found");
    
    const updatedNotification = { ...notification, read: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }

  async markNotificationEmailSent(id: number): Promise<Notification> {
    const notification = this.notifications.get(id);
    if (!notification) throw new Error("Notification not found");
    
    const updatedNotification = { ...notification, sentEmail: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
}

export const storage = new MemStorage();
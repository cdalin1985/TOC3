import * as bcrypt from 'bcrypt';
import { Strategy as LocalStrategy } from 'passport-local';
import passport from 'passport';
import { db } from './db';
import { users, userPlayers, players } from '@shared/schema';
import { and, eq } from 'drizzle-orm';
import type { User } from '@shared/schema';
import { Express, Request, Response, NextFunction } from 'express';

// Helper to hash passwords
export const hashPassword = async (password: string): Promise<string> => {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
};

// Helper to verify passwords
export const verifyPassword = async (password: string, hash: string): Promise<boolean> => {
  return bcrypt.compare(password, hash);
};

// Define passport strategy
export const configurePassport = () => {
  // Serialize user to session
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  // Deserialize user from session
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await db.select().from(users).where(eq(users.id, id)).limit(1);
      done(null, user[0] || null);
    } catch (err) {
      done(err, null);
    }
  });

  // Local strategy for username/password login
  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
      
      if (result.length === 0) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      
      const user = result[0];
      const isValid = await verifyPassword(password, user.passwordHash);
      
      if (!isValid) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));
};

// Authentication middleware
export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: 'Not authenticated' });
};

// Check if user owns a player
export const isPlayerOwner = async (req: Request, res: Response, next: NextFunction) => {
  const playerId = parseInt(req.params.id);
  const userId = (req.user as User).id;
  
  if (isNaN(playerId)) {
    return res.status(400).json({ error: 'Invalid player ID' });
  }
  
  try {
    const result = await db.select()
      .from(userPlayers)
      .where(and(
        eq(userPlayers.userId, userId),
        eq(userPlayers.playerId, playerId)
      ))
      .limit(1);
    
    if (result.length > 0) {
      return next();
    }
    
    res.status(403).json({ error: 'You do not have permission to manage this player' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Register auth routes
export const registerAuthRoutes = (app: Express) => {
  // Register route
  app.post('/api/auth/register', async (req, res) => {
    // Only extract specifically what we need from the request body
    const username = req.body.username;
    const password = req.body.password;
    const accountType = req.body.accountType;
    const playerId = req.body.playerId;
    
    if (!username || !password || !accountType) {
      return res.status(400).json({ error: 'Username, password, and account type are required' });
    }
    
    // For player accounts, validate playerId
    if (accountType === 'player' && !playerId) {
      return res.status(400).json({ error: 'Player selection is required for player accounts' });
    }
    
    try {
      // Check if username already exists
      const existingUser = await db.select({ id: users.id })
        .from(users)
        .where(eq(users.username, username))
        .limit(1);
      
      if (existingUser.length > 0) {
        return res.status(400).json({ error: 'Username already exists' });
      }
      
      // For player accounts, check if player already linked to another account
      if (accountType === 'player') {
        const playerIdNum = parseInt(playerId);
        
        // Check if player exists
        const playerResult = await db.select()
          .from(players)
          .where(eq(players.id, playerIdNum))
          .limit(1);
        
        if (playerResult.length === 0) {
          return res.status(404).json({ error: 'Selected player not found' });
        }
        
        // Check if player is already linked
        const existingLink = await db.select()
          .from(userPlayers)
          .where(eq(userPlayers.playerId, playerIdNum))
          .limit(1);
        
        if (existingLink.length > 0) {
          return res.status(400).json({ error: 'This player is already linked to another account' });
        }
      }
      
      // Hash password and create user
      const passwordHash = await hashPassword(password);
      
      // Create the user with only required fields
      const insertData = {
        username: username,
        passwordHash: passwordHash,
      };
      
      // Insert user
      const [user] = await db.insert(users)
        .values(insertData)
        .returning();
      
      // If player account, link the player to this user
      if (accountType === 'player' && playerId) {
        await db.insert(userPlayers)
          .values({
            userId: user.id,
            playerId: parseInt(playerId)
          });
      }
      
      // Log the user in
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: 'Error logging in' });
        }
        return res.json({ 
          id: user.id,
          username: user.username,
          accountType: accountType,
          playerId: accountType === 'player' ? parseInt(playerId) : null
        });
      });
    } catch (err) {
      console.error('Registration error:', err);
      res.status(500).json({ error: 'Error creating user' });
    }
  });
  
  // Login route
  app.post('/api/auth/login', passport.authenticate('local'), async (req, res) => {
    const user = req.user as User;
    
    try {
      // Check if user has a linked player
      const userPlayerLinks = await db.select({
        playerId: userPlayers.playerId
      })
      .from(userPlayers)
      .where(eq(userPlayers.userId, user.id))
      .limit(1);
      
      // If player link found, get the player information
      let player = null;
      let accountType = 'guest';
      
      if (userPlayerLinks.length > 0) {
        accountType = 'player';
        const playerId = userPlayerLinks[0].playerId;
        
        const playerResult = await db.select()
          .from(players)
          .where(eq(players.id, playerId))
          .limit(1);
          
        if (playerResult.length > 0) {
          player = playerResult[0];
        }
      }
      
      res.json({
        id: user.id,
        username: user.username,
        accountType,
        player
      });
    } catch (err) {
      console.error('Error fetching player data for login:', err);
      // If there's an error, return basic user info
      res.json({
        id: user.id,
        username: user.username,
        accountType: 'guest',
        player: null
      });
    }
  });
  
  // Logout route
  app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: 'Error logging out' });
      }
      res.json({ success: true });
    });
  });
  
  // Get current user
  app.get('/api/auth/user', async (req, res) => {
    if (!req.user) {
      return res.json(null);
    }
    
    const user = req.user as User;
    
    try {
      // Check if user has a linked player
      const userPlayerLinks = await db.select({
        playerId: userPlayers.playerId
      })
      .from(userPlayers)
      .where(eq(userPlayers.userId, user.id))
      .limit(1);
      
      // If player link found, get the player information
      let player = null;
      let accountType = 'guest';
      
      if (userPlayerLinks.length > 0) {
        accountType = 'player';
        const playerId = userPlayerLinks[0].playerId;
        
        const playerResult = await db.select()
          .from(players)
          .where(eq(players.id, playerId))
          .limit(1);
          
        if (playerResult.length > 0) {
          player = playerResult[0];
        }
      }
      
      res.json({
        id: user.id,
        username: user.username,
        accountType,
        player
      });
    } catch (err) {
      console.error('Error fetching user player data:', err);
      res.json({
        id: user.id,
        username: user.username,
        accountType: 'guest',
        player: null
      });
    }
  });
  
  // Link player to user account
  app.post('/api/auth/link-player/:playerId', isAuthenticated, async (req, res) => {
    const playerId = parseInt(req.params.playerId);
    const userId = (req.user as User).id;
    
    if (isNaN(playerId)) {
      return res.status(400).json({ error: 'Invalid player ID' });
    }
    
    try {
      // Check if player exists
      const playerResult = await db.select()
        .from(players)
        .where(eq(players.id, playerId))
        .limit(1);
      
      if (playerResult.length === 0) {
        return res.status(404).json({ error: 'Player not found' });
      }
      
      // Check if player is already linked
      const existingLink = await db.select()
        .from(userPlayers)
        .where(eq(userPlayers.playerId, playerId))
        .limit(1);
      
      if (existingLink.length > 0) {
        return res.status(400).json({ error: 'Player is already linked to an account' });
      }
      
      // Link player to user
      await db.insert(userPlayers)
        .values({
          userId,
          playerId
        });
      
      res.json({ success: true });
    } catch (err) {
      console.error('Error linking player:', err);
      res.status(500).json({ error: 'Server error' });
    }
  });
  
  // Get user's players
  app.get('/api/auth/my-players', isAuthenticated, async (req, res) => {
    const userId = (req.user as User).id;
    
    try {
      const result = await db.select({
        player: userPlayers.playerId
      })
      .from(userPlayers)
      .where(eq(userPlayers.userId, userId));
      
      const playerIds = result.map(r => r.player);
      
      if (playerIds.length === 0) {
        return res.json([]);
      }
      
      // Fetch players individually to avoid LSP error with inArray
      const playersResult = [];
      for (const id of playerIds) {
        const [player] = await db.select()
          .from(players)
          .where(eq(players.id, id))
          .limit(1);
          
        if (player) {
          playersResult.push(player);
        }
      }
      
      res.json(playersResult);
    } catch (err) {
      console.error('Error fetching player:', err);
      res.status(500).json({ error: 'Server error' });
    }
  });
};
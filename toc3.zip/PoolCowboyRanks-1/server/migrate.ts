import pg from 'pg';
import { db } from './db';
import * as schema from '../shared/schema';

async function migrate() {
  console.log('Starting migration...');
  
  const client = new pg.Client(process.env.DATABASE_URL);
  await client.connect();
  
  try {
    // First check if tables exist
    const checkUsersTable = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_name = 'users'
    `);
    
    if (checkUsersTable.rows.length === 0) {
      console.log('Creating tables from schema...');
      // Use drizzle-kit to push the schema to the database
      await db.execute(schema.users);
      await db.execute(schema.players);
      await db.execute(schema.userPlayers);
      await db.execute(schema.challenges);
      await db.execute(schema.matches);
      await db.execute(schema.tournaments);
      await db.execute(schema.tournamentPlayers);
      await db.execute(schema.tournamentMatches);
      await db.execute(schema.notifications);
      
      console.log('Created all tables successfully!');
    }
    
    // Check if phone_number column exists in users table
    const checkPhoneColumn = await client.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' AND column_name = 'phone_number'
    `);
    
    // If phone_number column doesn't exist and users table exists, create it
    if (checkPhoneColumn.rows.length === 0 && checkUsersTable.rows.length > 0) {
      console.log('Adding phone_number column to users table...');
      await client.query(`
        ALTER TABLE users
        ADD COLUMN phone_number TEXT
      `);
      console.log('Added phone_number column to users table.');
    } else if (checkUsersTable.rows.length > 0) {
      console.log('phone_number column already exists in users table.');
    }
    
    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration error:', error);
  } finally {
    await client.end();
  }
}

migrate().catch(console.error);
import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { 
  insertPlayerSchema, 
  insertChallengeSchema, 
  insertMatchSchema, 
  insertTournamentSchema, 
  insertTournamentPlayerSchema 
} from "@shared/schema";
import nodemailer from "nodemailer";
import { z } from "zod";

// Create a test email transporter
const emailTransporter = nodemailer.createTransport({
  host: "smtp.ethereal.email",
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER || "ethereal.user@ethereal.email", // use env variables in production
    pass: process.env.EMAIL_PASS || "ethereal.pass"
  }
});

// Email sending function
async function sendEmail(to: string, subject: string, text: string) {
  try {
    if (!to) return false; // Skip if no email address
    
    const info = await emailTransporter.sendMail({
      from: '"Helena Pool Rankings" <pool@helenapool.example.com>',
      to,
      subject,
      text,
      html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #3b82f6;">${subject}</h2>
        <p>${text}</p>
        <p>Visit the <a href="https://helenapool.example.com">Helena Pool Rankings</a> site for more details.</p>
      </div>`
    });
    
    console.log("Email sent:", info.messageId);
    return true;
  } catch (error) {
    console.error("Failed to send email:", error);
    return false;
  }
}

export async function registerRoutes(app: Express) {
  // Players
  app.get("/api/players", async (_req, res) => {
    const players = await storage.getPlayers();
    res.json(players);
  });

  app.get("/api/players/:id", async (req, res) => {
    const player = await storage.getPlayer(parseInt(req.params.id));
    if (!player) {
      return res.status(404).json({ error: "Player not found" });
    }
    res.json(player);
  });

  app.post("/api/players", async (req, res) => {
    const result = insertPlayerSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const player = await storage.createPlayer(result.data);
    res.json(player);
  });

  app.put("/api/players/:id/email", async (req, res) => {
    const { id } = req.params;
    const { email } = req.body;
    
    const emailSchema = z.string().email().optional();
    const result = emailSchema.safeParse(email);
    
    if (!result.success) {
      return res.status(400).json({ error: "Invalid email format" });
    }
    
    const player = await storage.updatePlayerEmail(parseInt(id), email || "");
    res.json(player);
  });
  
  app.post("/api/players/:id/rank", async (req, res) => {
    const { id } = req.params;
    const { newRank } = req.body;
    
    const rankSchema = z.number().int().positive();
    const result = rankSchema.safeParse(newRank);
    
    if (!result.success) {
      return res.status(400).json({ error: "Invalid rank format" });
    }
    
    const player = await storage.updatePlayerRank(parseInt(id), newRank);
    res.json(player);
  });

  // Player Statistics
  app.get("/api/players/:id/statistics", async (req, res) => {
    const playerId = parseInt(req.params.id);
    const player = await storage.getPlayer(playerId);
    
    if (!player) {
      return res.status(404).json({ error: "Player not found" });
    }
    
    const matches = await storage.getPlayerMatches(playerId);
    const challenges = await storage.getPlayerChallenges(playerId);
    
    // Calculate additional statistics
    const winPercentage = player.wins > 0 
      ? (player.wins / (player.wins + player.losses) * 100).toFixed(1) 
      : "0.0";
      
    const gameTypes = matches.reduce((acc, match) => {
      acc[match.gameType] = (acc[match.gameType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const mostPlayedAgainst = matches.reduce((acc, match) => {
      const opponentId = match.player1Id === playerId ? match.player2Id : match.player1Id;
      acc[opponentId] = (acc[opponentId] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);
    
    // Find the most frequent opponent
    const mostPlayedOpponentId = Object.entries(mostPlayedAgainst)
      .sort((a, b) => b[1] - a[1])
      .map(([id]) => parseInt(id))[0];
    
    const mostPlayedOpponent = mostPlayedOpponentId 
      ? await storage.getPlayer(mostPlayedOpponentId) 
      : null;
    
    res.json({
      player,
      matches: matches.length,
      challenges: challenges.length,
      winPercentage,
      gameTypes,
      mostPlayedOpponent: mostPlayedOpponent?.name || "None",
      recentMatches: matches.slice(-5)
    });
  });

  // Challenges
  app.get("/api/challenges", async (_req, res) => {
    const challenges = await storage.getChallenges();
    res.json(challenges);
  });

  app.get("/api/challenges/:id", async (req, res) => {
    const challenge = await storage.getChallenge(parseInt(req.params.id));
    if (!challenge) {
      return res.status(404).json({ error: "Challenge not found" });
    }
    res.json(challenge);
  });

  app.post("/api/challenges", async (req, res) => {
    const result = insertChallengeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    const challenge = await storage.createChallenge(result.data);
    
    // Create notification for defender
    const challenger = await storage.getPlayer(challenge.challengerId);
    const defender = await storage.getPlayer(challenge.defenderId);
    
    if (defender) {
      const notification = await storage.createNotification({
        playerId: defender.id,
        type: "challenge",
        message: `${challenger?.name || "A player"} has challenged you to a ${challenge.gameType} match!`,
        relatedId: challenge.id
      });
      
      // Send email notification if defender has an email
      if (defender.email) {
        const emailSent = await sendEmail(
          defender.email,
          "New Pool Challenge",
          `${challenger?.name || "A player"} has challenged you to a ${challenge.gameType} match to ${challenge.gamesToWin}. Log in to accept or reject this challenge.`
        );
        
        if (emailSent) {
          await storage.markNotificationEmailSent(notification.id);
        }
      }
    }
    
    res.json(challenge);
  });

  app.post("/api/challenges/:id/status", async (req, res) => {
    const { id } = req.params;
    const { status, winnerId } = req.body;
    
    if (!["accepted", "completed", "rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }

    const challenge = await storage.updateChallengeStatus(
      parseInt(id), 
      status, 
      winnerId
    );

    if (status === "completed" && winnerId) {
      const winner = await storage.updatePlayerStats(winnerId, true);
      const loserId = challenge.challengerId === winnerId 
        ? challenge.defenderId 
        : challenge.challengerId;
      const loser = await storage.updatePlayerStats(loserId, false);

      // Create match record
      await storage.createMatch({
        challengeId: challenge.id,
        player1Id: challenge.challengerId,
        player2Id: challenge.defenderId,
        player1Score: challenge.challengerId === winnerId ? challenge.gamesToWin : 0,
        player2Score: challenge.defenderId === winnerId ? challenge.gamesToWin : 0,
        winnerId,
        gameType: challenge.gameType
      });

      // Update rankings if winner was lower ranked
      if (winner && loser && winner.rank > loser.rank) {
        await storage.updatePlayerRank(winner.id, loser.rank);
        await storage.updatePlayerRank(loser.id, winner.rank);
        
        // Create notifications for rank changes
        await storage.createNotification({
          playerId: winner.id,
          type: "rankChange",
          message: `Congratulations! Your rank has improved from ${winner.rank} to ${loser.rank}!`,
          relatedId: challenge.id
        });
        
        await storage.createNotification({
          playerId: loser.id,
          type: "rankChange",
          message: `Your rank has changed from ${loser.rank} to ${winner.rank}.`,
          relatedId: challenge.id
        });
      }
      
      // Notify both players about the result
      await storage.createNotification({
        playerId: winner.id,
        type: "result",
        message: `You won your ${challenge.gameType} match!`,
        relatedId: challenge.id
      });
      
      await storage.createNotification({
        playerId: loserId,
        type: "result",
        message: `You lost your ${challenge.gameType} match.`,
        relatedId: challenge.id
      });
      
      // Send email notifications
      const winnerPlayer = await storage.getPlayer(winner.id);
      const loserPlayer = await storage.getPlayer(loserId);
      
      if (winnerPlayer?.email) {
        await sendEmail(
          winnerPlayer.email,
          "Match Result: Victory!",
          `Congratulations! You won your ${challenge.gameType} match against ${loserPlayer?.name || "your opponent"}!`
        );
      }
      
      if (loserPlayer?.email) {
        await sendEmail(
          loserPlayer.email,
          "Match Result",
          `You lost your ${challenge.gameType} match against ${winnerPlayer?.name || "your opponent"}. Better luck next time!`
        );
      }
    } else if (status === "accepted" || status === "rejected") {
      // Notify challenger about acceptance/rejection
      const defender = await storage.getPlayer(challenge.defenderId);
      await storage.createNotification({
        playerId: challenge.challengerId,
        type: "challenge",
        message: `${defender?.name || "Your opponent"} has ${status} your challenge!`,
        relatedId: challenge.id
      });
      
      // Send email notification
      const challenger = await storage.getPlayer(challenge.challengerId);
      if (challenger?.email) {
        await sendEmail(
          challenger.email,
          `Challenge ${status === "accepted" ? "Accepted" : "Rejected"}`,
          `${defender?.name || "Your opponent"} has ${status} your ${challenge.gameType} challenge.`
        );
      }
    }

    res.json(challenge);
  });

  // Matches
  app.get("/api/matches", async (_req, res) => {
    const matches = await storage.getMatches();
    res.json(matches);
  });

  app.get("/api/players/:id/matches", async (req, res) => {
    const matches = await storage.getPlayerMatches(parseInt(req.params.id));
    res.json(matches);
  });

  // Tournaments
  app.get("/api/tournaments", async (_req, res) => {
    const tournaments = await storage.getTournaments();
    res.json(tournaments);
  });

  app.get("/api/tournaments/:id", async (req, res) => {
    const tournament = await storage.getTournament(parseInt(req.params.id));
    if (!tournament) {
      return res.status(404).json({ error: "Tournament not found" });
    }
    
    // Get players and matches for this tournament
    const players = await storage.getTournamentPlayers(tournament.id);
    const matches = await storage.getTournamentMatches(tournament.id);
    
    res.json({
      ...tournament,
      players,
      matches
    });
  });

  app.post("/api/tournaments", async (req, res) => {
    const result = insertTournamentSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    const tournament = await storage.createTournament(result.data);
    
    // Notify all players with emails about the new tournament
    const players = await storage.getPlayers();
    for (const player of players) {
      if (player.email) {
        await storage.createNotification({
          playerId: player.id,
          type: "tournament",
          message: `New tournament: ${tournament.name} starting on ${tournament.startDate}`,
          relatedId: tournament.id
        });
        
        await sendEmail(
          player.email,
          `New Tournament: ${tournament.name}`,
          `A new ${tournament.gameType} tournament "${tournament.name}" has been scheduled to start on ${tournament.startDate}. Visit the site to register!`
        );
      }
    }
    
    res.json(tournament);
  });

  app.post("/api/tournaments/:id/status", async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!["upcoming", "active", "completed"].includes(status)) {
      return res.status(400).json({ error: "Invalid status" });
    }
    
    const tournament = await storage.updateTournamentStatus(parseInt(id), status);
    res.json(tournament);
  });

  app.post("/api/tournaments/:id/players", async (req, res) => {
    const { id } = req.params;
    const tournamentId = parseInt(id);
    
    const result = insertTournamentPlayerSchema.safeParse({
      ...req.body,
      tournamentId
    });
    
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    
    const tournamentPlayer = await storage.addPlayerToTournament(result.data);
    
    // Notify player about registration
    const player = await storage.getPlayer(tournamentPlayer.playerId);
    const tournament = await storage.getTournament(tournamentId);
    
    if (player) {
      await storage.createNotification({
        playerId: player.id,
        type: "tournament",
        message: `You have been registered for the "${tournament?.name}" tournament.`,
        relatedId: tournamentId
      });
      
      if (player.email) {
        await sendEmail(
          player.email,
          `Tournament Registration: ${tournament?.name}`,
          `You have been successfully registered for the "${tournament?.name}" tournament starting on ${tournament?.startDate}.`
        );
      }
    }
    
    res.json(tournamentPlayer);
  });

  app.post("/api/tournaments/:id/generate", async (req, res) => {
    const tournamentId = parseInt(req.params.id);
    const tournament = await storage.getTournament(tournamentId);
    
    if (!tournament) {
      return res.status(404).json({ error: "Tournament not found" });
    }
    
    if (tournament.status !== "upcoming") {
      return res.status(400).json({ error: "Can only generate brackets for upcoming tournaments" });
    }
    
    // Get registered players
    const players = await storage.getTournamentPlayers(tournamentId);
    if (players.length < 2) {
      return res.status(400).json({ error: "Need at least 2 players to generate brackets" });
    }
    
    // Simple single elimination bracket generation
    const rounds = Math.ceil(Math.log2(players.length));
    const totalMatches = Math.pow(2, rounds) - 1;
    
    // Generate matches
    const matches = [];
    for (let round = 1; round <= rounds; round++) {
      const matchesInRound = Math.pow(2, rounds - round);
      
      for (let matchNum = 1; matchNum <= matchesInRound; matchNum++) {
        const match: Partial<TournamentMatch> = {
          tournamentId,
          round,
          matchNumber: matchNum,
          status: "scheduled"
        };
        
        // Assign players to first round only
        if (round === 1) {
          const playerIndex1 = (matchNum - 1) * 2;
          const playerIndex2 = playerIndex1 + 1;
          
          if (playerIndex1 < players.length) {
            match.player1Id = players[playerIndex1].playerId;
          }
          
          if (playerIndex2 < players.length) {
            match.player2Id = players[playerIndex2].playerId;
          }
        }
        
        matches.push(await storage.createTournamentMatch(match));
      }
    }
    
    // Update tournament status to active
    await storage.updateTournamentStatus(tournamentId, "active");
    
    // Notify all participants
    for (const player of players) {
      await storage.createNotification({
        playerId: player.playerId,
        type: "tournament",
        message: `The "${tournament.name}" tournament has started. Check your matches!`,
        relatedId: tournamentId
      });
      
      const playerDetails = await storage.getPlayer(player.playerId);
      if (playerDetails?.email) {
        await sendEmail(
          playerDetails.email,
          `Tournament Started: ${tournament.name}`,
          `The "${tournament.name}" tournament has started. Check the site for your match schedule.`
        );
      }
    }
    
    res.json({ tournament, matches });
  });

  app.post("/api/tournaments/:tournamentId/matches/:matchId/result", async (req, res) => {
    const { tournamentId, matchId } = req.params;
    const { winnerId, score } = req.body;
    
    if (!winnerId || !score) {
      return res.status(400).json({ error: "Winner ID and score are required" });
    }
    
    const match = await storage.updateTournamentMatch(parseInt(matchId), parseInt(winnerId), score);
    
    // Notify players about result
    if (match.player1Id) {
      await storage.createNotification({
        playerId: match.player1Id,
        type: "tournament",
        message: `Your tournament match result: ${score}`,
        relatedId: parseInt(tournamentId)
      });
    }
    
    if (match.player2Id) {
      await storage.createNotification({
        playerId: match.player2Id,
        type: "tournament",
        message: `Your tournament match result: ${score}`,
        relatedId: parseInt(tournamentId)
      });
    }
    
    res.json(match);
  });

  // Notifications
  app.get("/api/players/:id/notifications", async (req, res) => {
    const notifications = await storage.getPlayerNotifications(parseInt(req.params.id));
    res.json(notifications);
  });

  app.post("/api/notifications/:id/read", async (req, res) => {
    const notification = await storage.markNotificationAsRead(parseInt(req.params.id));
    res.json(notification);
  });

  const httpServer = createServer(app);
  return httpServer;
}
